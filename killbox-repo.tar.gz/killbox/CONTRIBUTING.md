# Contributing to KILLBOX

See README.md for project structure.
Open issues for bugs, open PRs for features.
Do not commit API keys, malware samples, or offensive tooling.
