#!/usr/bin/env bash
# ============================================================
#  KILLBOX — Malware Analysis Framework Installer
#  Target: Debian 12 (Bookworm) / Debian 11 (Bullseye)
#  Also compatible with: Ubuntu 22.04+, Kali Linux
#  Run as root or with sudo
# ============================================================

set -euo pipefail

RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'
CYAN='\033[0;36m'; PURPLE='\033[0;35m'; NC='\033[0m'; BOLD='\033[1m'

KB_VERSION="2.4.1"
KB_DIR="/opt/killbox"
KB_USER="killbox"
LOG_FILE="/var/log/killbox-install.log"

banner() {
  echo -e "${PURPLE}"
  cat << 'EOF'
  ██╗  ██╗██╗██╗     ██╗     ██████╗  ██████╗ ██╗  ██╗
  ██║ ██╔╝██║██║     ██║     ██╔══██╗██╔═══██╗╚██╗██╔╝
  █████╔╝ ██║██║     ██║     ██████╔╝██║   ██║ ╚███╔╝
  ██╔═██╗ ██║██║     ██║     ██╔══██╗██║   ██║ ██╔██╗
  ██║  ██╗██║███████╗███████╗██████╔╝╚██████╔╝██╔╝ ██╗
  ╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝
       THREAT ANALYSIS FRAMEWORK  v2.4.1
       Debian/Ubuntu Edition — Full Stack Installer
EOF
  echo -e "${NC}"
}

log()     { echo -e "${GREEN}[+]${NC} $*" | tee -a "$LOG_FILE"; }
warn()    { echo -e "${YELLOW}[!]${NC} $*" | tee -a "$LOG_FILE"; }
error()   { echo -e "${RED}[✗]${NC} $*" | tee -a "$LOG_FILE"; exit 1; }
section() { echo -e "\n${CYAN}${BOLD}━━━ $* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | tee -a "$LOG_FILE"; }

check_root() {
  [[ $EUID -ne 0 ]] && error "Run as root: sudo bash install.sh"
}

check_os() {
  if [[ -f /etc/os-release ]]; then
    source /etc/os-release
    log "Detected OS: $NAME $VERSION_ID"
    case "$ID" in
      debian|ubuntu|kali|parrot|linuxmint) ;;
      *) warn "Untested OS: $ID — proceeding anyway" ;;
    esac
  else
    warn "Cannot detect OS — proceeding anyway"
  fi
}

check_disk() {
  AVAIL=$(df /opt --output=avail -BG | tail -1 | tr -d 'G')
  [[ $AVAIL -lt 5 ]] && error "Need at least 5GB free on /opt (have ${AVAIL}GB)"
  log "Disk space OK: ${AVAIL}GB available"
}

# ── SYSTEM PACKAGES ──────────────────────────────────────────────────────────
install_system_packages() {
  section "System Packages"
  apt-get update -qq 2>&1 | tee -a "$LOG_FILE"
  apt-get install -y --no-install-recommends \
    curl wget git unzip tar gzip bzip2 xz-utils \
    build-essential gcc g++ make cmake pkg-config \
    libssl-dev libffi-dev zlib1g-dev libbz2-dev \
    libreadline-dev libsqlite3-dev libncurses5-dev \
    python3 python3-pip python3-dev python3-venv \
    python3-setuptools python3-wheel \
    nodejs npm \
    binutils file xxd hexedit \
    strings nasm \
    libmagic1 libmagic-dev \
    libjansson-dev libjansson4 \
    libpcre3 libpcre3-dev \
    libclamav-dev clamav clamav-daemon freshclam \
    tcpdump tshark wireshark-common \
    nmap netcat-openbsd dnsutils whois \
    libnet1-dev libpcap-dev \
    p7zip-full cabextract unrar-free \
    exiftool \
    sqlite3 libsqlite3-dev \
    jq \
    openssl \
    strace ltrace \
    2>&1 | tee -a "$LOG_FILE"
  log "System packages installed"
}

# ── NODE.JS (LTS via NodeSource) ──────────────────────────────────────────────
install_nodejs() {
  section "Node.js LTS"
  if node --version 2>/dev/null | grep -q "v2[01]"; then
    log "Node.js $(node --version) already installed"
    return
  fi
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - 2>&1 | tee -a "$LOG_FILE"
  apt-get install -y nodejs 2>&1 | tee -a "$LOG_FILE"
  log "Node.js $(node --version) installed"
}

# ── PYTHON TOOLS (virtualenv) ─────────────────────────────────────────────────
install_python_tools() {
  section "Python Analysis Tools"
  python3 -m venv "$KB_DIR/venv"
  source "$KB_DIR/venv/bin/activate"

  pip install --quiet --upgrade pip wheel setuptools

  # Core malware analysis
  pip install --quiet \
    pefile \
    yara-python \
    python-magic \
    oletools \
    pdfid \
    peepdf2 \
    androguard \
    capstone \
    unicorn \
    r2pipe \
    frida \
    floss \
    capa \
    dnspython \
    requests \
    beautifulsoup4 \
    lxml \
    chardet \
    pyOpenSSL \
    cryptography \
    scapy \
    impacket \
    volatility3 \
    email-validator \
    mailparser \
    dkimpy \
    pyspf \
    checkdmarc \
    pylnk3 \
    compressed-rtf \
    extract-msg \
    msoffcrypto-tool \
    exifread \
    sigmatools \
    stix2 \
    taxii2-client \
    misp-lib-stix2 \
    pymisp \
    2>&1 | tee -a "$LOG_FILE"

  log "Python tools installed in venv"
  deactivate
}

# ── YARA ──────────────────────────────────────────────────────────────────────
install_yara() {
  section "YARA Engine"
  if command -v yara &>/dev/null; then
    log "YARA $(yara --version) already installed"
    return
  fi
  apt-get install -y yara 2>&1 | tee -a "$LOG_FILE" || {
    warn "apt YARA failed, building from source"
    YARA_VER="4.5.1"
    cd /tmp
    wget -q "https://github.com/VirusTotal/yara/releases/download/v${YARA_VER}/yara-${YARA_VER}.tar.gz"
    tar xf "yara-${YARA_VER}.tar.gz"
    cd "yara-${YARA_VER}"
    ./bootstrap.sh && ./configure --with-crypto --enable-magic --enable-cuckoo
    make -j"$(nproc)" && make install
    ldconfig
  }
  log "YARA $(yara --version) ready"
}

# ── RADARE2 ───────────────────────────────────────────────────────────────────
install_radare2() {
  section "Radare2"
  if command -v r2 &>/dev/null; then
    log "Radare2 already installed"
    return
  fi
  cd /tmp
  git clone --depth=1 https://github.com/radareorg/radare2.git 2>&1 | tee -a "$LOG_FILE"
  cd radare2
  sys/install.sh 2>&1 | tee -a "$LOG_FILE"
  log "Radare2 installed"
}

# ── ADDITIONAL STATIC TOOLS ───────────────────────────────────────────────────
install_static_tools() {
  section "Static Analysis Tools"

  # Binwalk
  pip3 install binwalk 2>&1 | tee -a "$LOG_FILE" || \
    apt-get install -y binwalk 2>&1 | tee -a "$LOG_FILE"

  # Detect-It-Easy (die) for packer detection
  apt-get install -y die 2>&1 | tee -a "$LOG_FILE" || \
    warn "die not in repos — install manually from github.com/horsicq/Detect-It-Easy"

  # Foremost (file carving)
  apt-get install -y foremost 2>&1 | tee -a "$LOG_FILE"

  # Bulk-extractor
  apt-get install -y bulk-extractor 2>&1 | tee -a "$LOG_FILE" || warn "bulk-extractor unavailable"

  log "Static tools installed"
}

# ── NETWORK/PCAP TOOLS ────────────────────────────────────────────────────────
install_network_tools() {
  section "Network Analysis Tools"
  apt-get install -y \
    zeek zeek-core zeekctl \
    suricata \
    snort \
    2>&1 | tee -a "$LOG_FILE" || warn "Some network tools unavailable in repos"

  # NetworkMiner (mono)
  apt-get install -y mono-complete 2>&1 | tee -a "$LOG_FILE" || warn "mono not available"

  log "Network tools installed"
}

# ── YARA COMMUNITY RULES ──────────────────────────────────────────────────────
install_yara_rules() {
  section "YARA Community Rules"
  mkdir -p "$KB_DIR/rules"
  cd "$KB_DIR/rules"

  # YARA-Rules project
  git clone --depth=1 https://github.com/Yara-Rules/rules.git yara-rules 2>&1 | tee -a "$LOG_FILE" || \
    warn "Could not clone YARA-Rules"

  # ReversingLabs YARA rules
  git clone --depth=1 https://github.com/reversinglabs/reversinglabs-yara-rules.git rl-rules 2>&1 | tee -a "$LOG_FILE" || \
    warn "Could not clone ReversingLabs rules"

  # Signature-Base (Florian Roth)
  git clone --depth=1 https://github.com/Neo23x0/signature-base.git signature-base 2>&1 | tee -a "$LOG_FILE" || \
    warn "Could not clone signature-base"

  log "YARA rule sets installed to $KB_DIR/rules"
}

# ── SIGMA RULES ───────────────────────────────────────────────────────────────
install_sigma_rules() {
  section "Sigma Detection Rules"
  mkdir -p "$KB_DIR/sigma"
  git clone --depth=1 https://github.com/SigmaHQ/sigma.git "$KB_DIR/sigma" 2>&1 | tee -a "$LOG_FILE" || \
    warn "Could not clone Sigma rules"
  log "Sigma rules installed"
}

# ── MITRE ATT&CK DATA ────────────────────────────────────────────────────────
install_mitre_data() {
  section "MITRE ATT&CK Dataset"
  mkdir -p "$KB_DIR/mitre"
  cd "$KB_DIR/mitre"
  wget -q "https://raw.githubusercontent.com/mitre/cti/master/enterprise-attack/enterprise-attack.json" \
    -O enterprise-attack.json 2>&1 | tee -a "$LOG_FILE" || warn "Could not fetch MITRE ATT&CK data"
  log "MITRE ATT&CK data installed"
}

# ── WEB APPLICATION (KILLBOX UI) ──────────────────────────────────────────────
install_web_app() {
  section "KILLBOX Web Interface"
  mkdir -p "$KB_DIR/app"

  cp -r /tmp/killbox-src/* "$KB_DIR/app/" 2>/dev/null || true

  cat > "$KB_DIR/app/package.json" << 'PKGJSON'
{
  "name": "killbox",
  "version": "2.4.1",
  "private": true,
  "dependencies": {
    "react": "^18.3.0",
    "react-dom": "^18.3.0",
    "@anthropic-ai/sdk": "^0.28.0"
  },
  "devDependencies": {
    "vite": "^5.4.0",
    "@vitejs/plugin-react": "^4.3.0"
  },
  "scripts": {
    "dev": "vite --host 0.0.0.0 --port 8080",
    "build": "vite build",
    "preview": "vite preview --host 0.0.0.0 --port 8080"
  }
}
PKGJSON

  cat > "$KB_DIR/app/vite.config.js" << 'VITECFG'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
export default defineConfig({
  plugins: [react()],
  server: { host: '0.0.0.0', port: 8080 },
  build: { outDir: 'dist' }
})
VITECFG

  cat > "$KB_DIR/app/index.html" << 'HTML'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>KILLBOX — Threat Analysis Engine</title>
  <style>* { box-sizing: border-box; margin: 0; padding: 0; }</style>
</head>
<body>
  <div id="root"></div>
  <script type="module" src="/src/main.jsx"></script>
</body>
</html>
HTML

  mkdir -p "$KB_DIR/app/src"
  cat > "$KB_DIR/app/src/main.jsx" << 'MAIN'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
ReactDOM.createRoot(document.getElementById('root')).render(<App />)
MAIN

  # Copy the main App component (killbox.jsx → App.jsx)
  if [[ -f "$KB_DIR/app/killbox.jsx" ]]; then
    cp "$KB_DIR/app/killbox.jsx" "$KB_DIR/app/src/App.jsx"
  fi

  cd "$KB_DIR/app" && npm install --silent 2>&1 | tee -a "$LOG_FILE"
  log "Web app dependencies installed"
}

# ── SYSTEMD SERVICE ───────────────────────────────────────────────────────────
install_systemd_service() {
  section "Systemd Service"
  cat > /etc/systemd/system/killbox.service << SERVICE
[Unit]
Description=KILLBOX Threat Analysis Framework
After=network.target
StartLimitIntervalSec=0

[Service]
Type=simple
User=root
WorkingDirectory=${KB_DIR}/app
ExecStart=/usr/bin/npm run dev
Restart=always
RestartSec=5
Environment=NODE_ENV=production
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SERVICE

  systemctl daemon-reload
  systemctl enable killbox.service
  log "Systemd service installed (killbox.service)"
}

# ── CLI TOOLS ─────────────────────────────────────────────────────────────────
install_cli_tools() {
  section "KILLBOX CLI Tools"
  mkdir -p "$KB_DIR/bin"

  # kb-scan: quick CLI wrapper for common analysis tasks
  cat > "$KB_DIR/bin/kb-scan" << 'KBSCAN'
#!/usr/bin/env bash
# KILLBOX quick scan CLI
VENV="/opt/killbox/venv"
source "$VENV/bin/activate"

usage() {
  echo "kb-scan — KILLBOX quick analysis"
  echo "  -f <file>       Static file analysis (strings, entropy, hashes)"
  echo "  -e <eml>        Email forensics (.eml file)"
  echo "  -y <file>       Generate YARA rule from file"
  echo "  -u <url>        Analyze suspicious URL"
  echo "  -i <ip>         IP reputation / geolocation"
  echo "  -p <pcap>       PCAP network analysis"
  echo "  -h              Help"
}

analyze_file() {
  echo "━━━ KILLBOX STATIC ANALYSIS ━━━━━━━━━━━━━━━━"
  echo "[*] File: $1"
  echo "[*] Size: $(stat -c%s "$1") bytes"
  echo ""
  echo "─── Hashes ──────────────────────────────────"
  echo "MD5:    $(md5sum "$1" | cut -d' ' -f1)"
  echo "SHA1:   $(sha1sum "$1" | cut -d' ' -f1)"
  echo "SHA256: $(sha256sum "$1" | cut -d' ' -f1)"
  echo ""
  echo "─── File Type ───────────────────────────────"
  file "$1"
  echo ""
  echo "─── Entropy ─────────────────────────────────"
  python3 -c "
import math, sys
data = open('$1','rb').read()
if not data: print('Empty file'); sys.exit()
freq = [0]*256
for b in data: freq[b] += 1
entropy = -sum((f/len(data))*math.log2(f/len(data)) for f in freq if f > 0)
print(f'Entropy: {entropy:.4f}/8.0 ({\"HIGH — packed/encrypted\" if entropy > 7.0 else \"MEDIUM — compressed\" if entropy > 6.0 else \"NORMAL\"})')
"
  echo ""
  echo "─── Suspicious Strings ──────────────────────"
  strings "$1" | grep -iE \
    'CreateRemoteThread|VirtualAlloc|WriteProcessMemory|LoadLibrary|WinExec|ShellExecute|
     RegSetValue|Software\\\\Microsoft\\\\Windows|cmd\.exe|powershell|base64|eval|exec|
     http://|https://|ftp://|\.onion|/bin/sh|/bin/bash' 2>/dev/null | head -30
  echo ""
  echo "─── YARA Quick Scan ─────────────────────────"
  yara /opt/killbox/rules/signature-base/yara/*.yar "$1" 2>/dev/null | head -10 || echo "No YARA matches (rules may not be installed)"
}

analyze_email() {
  echo "━━━ KILLBOX EMAIL FORENSICS ━━━━━━━━━━━━━━━━"
  echo "[*] File: $1"
  python3 -c "
import email, sys
from email import policy
msg = email.message_from_file(open('$1'), policy=policy.default)
print('From:   ', msg.get('From','N/A'))
print('To:     ', msg.get('To','N/A'))
print('Subject:', msg.get('Subject','N/A'))
print('Date:   ', msg.get('Date','N/A'))
print()
print('─── Received Chain ───')
for r in msg.get_all('Received', []):
    print('  >', r.strip()[:100])
print()
print('─── Auth Results ───')
for h in ['Authentication-Results','DKIM-Signature','Received-SPF']:
    v = msg.get(h)
    if v: print(f'{h}: {v[:150]}')
print()
print('─── Attachments ───')
for part in msg.walk():
    if part.get_content_disposition() == 'attachment':
        print(f'  Attachment: {part.get_filename()} ({part.get_content_type()})')
" 2>/dev/null || echo "Parse error — check file format"
}

case "$1" in
  -f) analyze_file "$2" ;;
  -e) analyze_email "$2" ;;
  -y) echo "YARA rule generation — use the web UI or kb-yara tool" ;;
  -i) python3 -c "import socket,json,urllib.request; ip='$2'; r=urllib.request.urlopen(f'http://ip-api.com/json/{ip}',timeout=5); print(json.loads(r.read().decode()))" 2>/dev/null ;;
  -h|*) usage ;;
esac
KBSCAN

  chmod +x "$KB_DIR/bin/kb-scan"
  ln -sf "$KB_DIR/bin/kb-scan" /usr/local/bin/kb-scan

  log "CLI tools installed: kb-scan"
}

# ── CLAMAV UPDATE ─────────────────────────────────────────────────────────────
update_clamav() {
  section "ClamAV Database"
  freshclam 2>&1 | tee -a "$LOG_FILE" || warn "freshclam failed — run manually later"
  log "ClamAV database updated"
}

# ── CLEANUP ───────────────────────────────────────────────────────────────────
cleanup() {
  section "Cleanup"
  apt-get autoremove -y -qq 2>&1 | tee -a "$LOG_FILE"
  apt-get clean 2>&1 | tee -a "$LOG_FILE"
  rm -rf /tmp/yara-* /tmp/radare2 2>/dev/null || true
  log "Cleanup done"
}

# ── PRINT SUMMARY ─────────────────────────────────────────────────────────────
print_summary() {
  local IP
  IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "127.0.0.1")
  echo ""
  echo -e "${PURPLE}${BOLD}"
  echo "  ╔══════════════════════════════════════════════╗"
  echo "  ║         KILLBOX INSTALLATION COMPLETE        ║"
  echo "  ╠══════════════════════════════════════════════╣"
  echo -e "  ║  Web UI:  ${CYAN}http://${IP}:8080${PURPLE}              ║"
  echo "  ║  Install: /opt/killbox                       ║"
  echo "  ║  Rules:   /opt/killbox/rules/                ║"
  echo "  ║  Sigma:   /opt/killbox/sigma/                ║"
  echo "  ║  MITRE:   /opt/killbox/mitre/                ║"
  echo "  ║  CLI:     kb-scan -h                         ║"
  echo "  ║  Logs:    /var/log/killbox-install.log       ║"
  echo "  ╠══════════════════════════════════════════════╣"
  echo "  ║  Start:   systemctl start killbox            ║"
  echo "  ║  Status:  systemctl status killbox           ║"
  echo -e "  ╚══════════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "${YELLOW}  ⬥ Configure your Anthropic API key in the web UI${NC}"
  echo -e "${YELLOW}  ⬥ For offline use: set ANTHROPIC_API_KEY in environment${NC}"
  echo ""
}

# ── MAIN ──────────────────────────────────────────────────────────────────────
main() {
  mkdir -p "$(dirname "$LOG_FILE")"
  touch "$LOG_FILE"
  mkdir -p "$KB_DIR"

  banner
  check_root
  check_os
  check_disk

  install_system_packages
  install_nodejs
  install_yara
  install_python_tools
  install_static_tools
  install_network_tools
  install_yara_rules
  install_sigma_rules
  install_mitre_data
  install_web_app
  install_cli_tools
  install_systemd_service
  update_clamav
  cleanup
  print_summary
}

main "$@"
