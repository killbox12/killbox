#!/usr/bin/env python3
"""
KILLBOX — Threat Enrichment CLI Module
Integrates: VirusTotal v3, AbuseIPDB v2, Local Heuristic Engine
Usage: python3 kb_enrich.py [--vt-hash|--vt-url|--vt-domain|--vt-ip|--abuse|--heuristic] <target>
"""

import sys, os, json, re, hashlib, math, argparse, time
from pathlib import Path

try:
    import requests
except ImportError:
    print("[!] requests not installed: pip install requests")
    sys.exit(1)

# ─── COLOUR HELPERS ────────────────────────────────────────────────────────────
R="\033[91m"; Y="\033[93m"; G="\033[92m"; C="\033[96m"; P="\033[95m"; D="\033[2m"; N="\033[0m"; B="\033[1m"
def red(s): return f"{R}{s}{N}"
def green(s): return f"{G}{s}{N}"
def yellow(s): return f"{Y}{s}{N}"
def cyan(s): return f"{C}{s}{N}"
def purple(s): return f"{P}{s}{N}"
def bold(s): return f"{B}{s}{N}"
def dim(s): return f"{D}{s}{N}"

def header(title, target):
    print(f"\n{P}{'━'*55}{N}")
    print(f"{P}{B}  KILLBOX / {title}{N}")
    print(f"{C}  Target : {target}{N}")
    print(f"{D}  Time   : {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())}{N}")
    print(f"{P}{'━'*55}{N}\n")

# ─── CONFIG ────────────────────────────────────────────────────────────────────
KB_DIR = Path("/opt/killbox")
CONFIG_FILE = KB_DIR / "config.json"

def load_config():
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}

def save_config(cfg):
    KB_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))

def get_key(name):
    env_map = {"vt": "VT_API_KEY", "abuse": "ABUSEIPDB_API_KEY", "claude": "ANTHROPIC_API_KEY"}
    env_val = os.environ.get(env_map.get(name, ""), "")
    if env_val: return env_val
    cfg = load_config()
    return cfg.get(f"{name}_api_key", "")

# ─── VIRUSTOTAL MODULE ─────────────────────────────────────────────────────────
VT_BASE = "https://www.virustotal.com/api/v3"

ABUSE_CATS = {
    1:"DNS Compromise", 2:"DNS Poisoning", 3:"Fraud Orders", 4:"DDoS Attack",
    5:"FTP Brute-Force", 6:"Ping of Death", 7:"Phishing", 8:"Fraud VoIP",
    9:"Open Proxy", 10:"Web Spam", 11:"Email Spam", 12:"Blog Spam", 13:"VPN IP",
    14:"Port Scan", 15:"Hacking", 16:"SQL Injection", 17:"Spoofing",
    18:"Brute-Force", 19:"Bad Web Bot", 20:"Exploited Host", 21:"Web App Attack",
    22:"SSH Brute-Force", 23:"IoT Targeted"
}

def vt_request(endpoint, api_key):
    headers = {"x-apikey": api_key}
    r = requests.get(f"{VT_BASE}{endpoint}", headers=headers, timeout=30)
    if r.status_code == 404:
        return None, "Not found in VirusTotal database"
    if r.status_code == 401:
        return None, "Invalid API key"
    if r.status_code == 429:
        return None, "Rate limit exceeded (free tier: 4 req/min)"
    r.raise_for_status()
    return r.json(), None

def print_vt_stats(stats, label="Detection Summary"):
    if not stats: return
    total = sum(stats.values())
    mal   = stats.get("malicious", 0)
    sus   = stats.get("suspicious", 0)
    undet = stats.get("undetected", 0)
    pct   = (mal / total * 100) if total else 0
    color = red if pct > 50 else yellow if pct > 20 else (yellow if pct > 5 else green)
    bar_filled = int(pct / 2.5)
    bar = "█" * bar_filled + "░" * (40 - bar_filled)
    print(f"  {bold(label)}")
    print(f"  [{color(bar)}] {color(f'{mal}/{total}')} ({pct:.1f}%)")
    print(f"  Malicious:{mal}  Suspicious:{sus}  Undetected:{undet}  Total:{total}")

def vt_hash(file_hash, api_key):
    header("VIRUSTOTAL / FILE HASH", file_hash)
    data, err = vt_request(f"/files/{file_hash.strip()}", api_key)
    if err: print(red(f"  ✗ {err}")); return

    attrs = data.get("data", {}).get("attributes", {})
    stats = attrs.get("last_analysis_stats", {})

    print(f"  {bold('File Info')}")
    for field, label in [("meaningful_name","Name"),("md5","MD5"),("sha1","SHA1"),
                          ("sha256","SHA256"),("size","Size"),("type_description","Type"),
                          ("magic","Magic"),("first_submission_date","First Seen"),
                          ("last_submission_date","Last Seen"),("times_submitted","Submissions")]:
        val = attrs.get(field)
        if val:
            if "date" in field: val = time.strftime('%Y-%m-%d', time.gmtime(val))
            elif field == "size": val = f"{val:,} bytes ({val/1024:.1f} KB)"
            print(f"  {D}{label:20s}{N} {cyan(str(val))}")

    print()
    print_vt_stats(stats)

    # Top malicious detections
    results = attrs.get("last_analysis_results", {})
    hits = [(eng, v) for eng, v in results.items() if v.get("category") in ("malicious","suspicious")]
    if hits:
        print(f"\n  {bold('Detections')}")
        for eng, v in sorted(hits, key=lambda x: x[1]["category"])[:20]:
            cat_color = red if v["category"]=="malicious" else yellow
            print(f"  {cat_color('⬥'):3s} {eng:30s} {cat_color(v.get('result','detected'))}")

    # Tags
    tags = attrs.get("tags", [])
    if tags:
        print(f"\n  {bold('Tags')} {' '.join(yellow(t) for t in tags)}")

    # Sandbox
    sb = attrs.get("sandbox_verdicts", {})
    if sb:
        print(f"\n  {bold('Sandbox Verdicts')}")
        for name, v in list(sb.items())[:5]:
            vc = red(v.get("verdict","?")) if "malicious" in str(v.get("category","")) else yellow(v.get("verdict","?"))
            families = ", ".join(v.get("malware_names",[])[:3])
            print(f"  {name:30s} {vc} {purple(families) if families else ''}")

    # MITRE
    mitre = attrs.get("popular_threat_classification", {}).get("popular_threat_category", [])
    if mitre:
        print(f"\n  {bold('Threat Categories')} {' '.join(cyan(m['value']) for m in mitre[:5])}")

    # Network IOCs
    contacted = attrs.get("contacted_domains", []) or attrs.get("contacted_ips", [])
    if contacted:
        print(f"\n  {bold('Contacted Infrastructure (top 10)')}")
        for ioc in contacted[:10]:
            print(f"  {red('⬥')} {ioc}")

def vt_url(url, api_key):
    import base64
    header("VIRUSTOTAL / URL", url[:80])
    url_id = base64.urlsafe_b64encode(url.strip().encode()).decode().rstrip("=")
    data, err = vt_request(f"/urls/{url_id}", api_key)
    if err:
        # Try submitting first
        print(yellow("  Submitting URL for analysis..."))
        r = requests.post(f"{VT_BASE}/urls", headers={"x-apikey":api_key}, data={"url":url}, timeout=30)
        if r.status_code == 200:
            analysis_id = r.json().get("data",{}).get("id","")
            time.sleep(5)
            data, err = vt_request(f"/analyses/{analysis_id}", api_key)
        if err: print(red(f"  ✗ {err}")); return

    attrs = data.get("data", {}).get("attributes", {})
    stats = attrs.get("stats") or attrs.get("last_analysis_stats", {})

    print_vt_stats(stats, "URL Detection Summary")

    for field, label in [("final_url","Final URL"),("title","Page Title"),("last_analysis_date","Last Analyzed")]:
        val = attrs.get(field)
        if val:
            if "date" in field: val = time.strftime('%Y-%m-%d', time.gmtime(val))
            print(f"  {D}{label:20s}{N} {cyan(str(val)[:100])}")

    cats = attrs.get("categories", {})
    if cats:
        print(f"\n  {bold('Categories')} {' '.join(yellow(v) for v in list(cats.values())[:5])}")

def vt_domain(domain, api_key):
    header("VIRUSTOTAL / DOMAIN", domain)
    data, err = vt_request(f"/domains/{domain.strip()}", api_key)
    if err: print(red(f"  ✗ {err}")); return

    attrs = data.get("data", {}).get("attributes", {})
    stats = attrs.get("last_analysis_stats", {})

    print_vt_stats(stats, "Domain Detection Summary")

    for field, label in [("registrar","Registrar"),("creation_date","Created"),
                          ("last_update_date","Updated"),("country","Country"),
                          ("reputation","Reputation")]:
        val = attrs.get(field)
        if val:
            print(f"  {D}{label:20s}{N} {cyan(str(val))}")

    whois = attrs.get("whois", "")
    if whois:
        print(f"\n  {bold('WHOIS (excerpt)')}")
        for line in whois.splitlines()[:15]:
            if any(k in line.lower() for k in ["registrar","created","updated","expires","name server","status"]):
                print(f"  {dim(line)}")

    dns_records = attrs.get("last_dns_records", [])
    if dns_records:
        print(f"\n  {bold('DNS Records')}")
        for r in dns_records[:15]:
            print(f"  {cyan(r.get('type','?'):6s)} {r.get('value','')[:80]}")

def vt_ip(ip, api_key):
    header("VIRUSTOTAL / IP ADDRESS", ip)
    data, err = vt_request(f"/ip_addresses/{ip.strip()}", api_key)
    if err: print(red(f"  ✗ {err}")); return

    attrs = data.get("data", {}).get("attributes", {})
    stats = attrs.get("last_analysis_stats", {})

    print_vt_stats(stats, "IP Detection Summary")

    for field, label in [("country","Country"),("as_owner","AS Owner"),("asn","ASN"),
                          ("network","Network"),("reputation","Reputation")]:
        val = attrs.get(field)
        if val:
            print(f"  {D}{label:20s}{N} {cyan(str(val))}")

    resolutions = data.get("data",{}).get("relationships",{}).get("resolutions",{}).get("data",[])
    if resolutions:
        print(f"\n  {bold('Historical Resolutions (sample)')}")
        for r in resolutions[:10]:
            print(f"  ⬥ {r.get('id','')}")

# ─── ABUSEIPDB MODULE ──────────────────────────────────────────────────────────
ABUSE_BASE = "https://api.abuseipdb.com/api/v2"

def abuse_check(ip, api_key, max_age=90, verbose=True):
    header("ABUSEIPDB / IP CHECK", ip)
    params = {"ipAddress": ip.strip(), "maxAgeInDays": max_age, "verbose": str(verbose).lower()}
    headers = {"Key": api_key, "Accept": "application/json"}
    r = requests.get(f"{ABUSE_BASE}/check", params=params, headers=headers, timeout=30)
    if r.status_code == 401: print(red("  ✗ Invalid AbuseIPDB API key")); return
    if r.status_code == 422: print(red(f"  ✗ Invalid IP address: {ip}")); return
    r.raise_for_status()
    data = r.json().get("data", {})

    score = data.get("abuseConfidenceScore", 0)
    score_color = red if score > 75 else yellow if score > 50 else (yellow if score > 25 else green)

    print(f"  {'IP Address':20s} {bold(cyan(data.get('ipAddress','?')))}")
    print(f"  {'Domain (rDNS)':20s} {data.get('domain','N/A')}")
    print(f"  {'Country':20s} {data.get('countryName','?')} ({data.get('countryCode','?')})")
    print(f"  {'ISP':20s} {data.get('isp','Unknown')}")
    print(f"  {'Usage Type':20s} {data.get('usageType','Unknown')}")
    print(f"  {'ASN':20s} {data.get('asn','?')}")

    flags = []
    if data.get("isTor"): flags.append(red("TOR EXIT NODE"))
    if data.get("isPublic") is False: flags.append(yellow("PRIVATE IP"))
    if data.get("usageType","").lower() in ("hosting","datacenter"): flags.append(yellow("HOSTING/DC"))
    if flags: print(f"  {'Flags':20s} {' | '.join(flags)}")

    print()
    bar = "█" * int(score / 2.5) + "░" * (40 - int(score / 2.5))
    print(f"  {bold('Abuse Confidence Score')}")
    print(f"  [{score_color(bar)}] {score_color(bold(f'{score}%'))}")
    print()
    print(f"  {'Total Reports':20s} {data.get('totalReports', 0)}")
    print(f"  {'Distinct Users':20s} {data.get('numDistinctUsers', 0)}")
    print(f"  {'Last Reported':20s} {data.get('lastReportedAt','Never')}")

    # Category breakdown from reports
    reports = data.get("reports", [])
    if reports:
        all_cats = {}
        for rep in reports:
            for c in rep.get("categories", []):
                all_cats[c] = all_cats.get(c, 0) + 1
        if all_cats:
            print(f"\n  {bold('Attack Categories')}")
            for cat_id, count in sorted(all_cats.items(), key=lambda x:-x[1]):
                name = ABUSE_CATS.get(cat_id, f"Category {cat_id}")
                print(f"  {red('⬥'):3s} {name:30s} ×{count}")

        print(f"\n  {bold('Recent Reports (latest 5)')}")
        for rep in reports[:5]:
            cats = [ABUSE_CATS.get(c, str(c)) for c in rep.get("categories", [])]
            comment = rep.get("comment","No comment")[:80]
            print(f"  {dim(rep.get('reportedAt','')[:10])}  {', '.join(cats)}")
            print(f"  {dim('  '+comment)}")

    # Verdict
    verdict = "BLOCK" if score > 75 else "MONITOR" if score > 25 else "WATCHLIST" if score > 5 else "CLEAN"
    verdict_color = red if verdict=="BLOCK" else yellow if verdict in ("MONITOR","WATCHLIST") else green
    print(f"\n  {bold('Recommendation')} {verdict_color(bold(f'⬥ {verdict}'))}")

def abuse_bulk(ip_list, api_key):
    """Check multiple IPs and produce a ranked table"""
    print(f"\n{P}{'━'*55}{N}")
    print(f"{P}{B}  KILLBOX / ABUSEIPDB BULK CHECK ({len(ip_list)} IPs){N}")
    print(f"{P}{'━'*55}{N}\n")

    results = []
    headers = {"Key": api_key, "Accept": "application/json"}
    for ip in ip_list[:30]:
        try:
            r = requests.get(f"{ABUSE_BASE}/check", params={"ipAddress":ip,"maxAgeInDays":90},
                             headers=headers, timeout=15)
            if r.status_code == 200:
                d = r.json().get("data",{})
                results.append(d)
                print(f"  ✓ {ip:20s} Score: {d.get('abuseConfidenceScore',0):3d}%")
            else:
                print(f"  ✗ {ip:20s} HTTP {r.status_code}")
        except Exception as e:
            print(f"  ✗ {ip:20s} {e}")
        time.sleep(0.5)  # be nice to the API

    results.sort(key=lambda x: x.get("abuseConfidenceScore",0), reverse=True)
    print(f"\n{'─'*70}")
    print(f"{'IP':20s} {'Country':6s} {'Score':7s} {'Reports':8s} {'ISP'}")
    print(f"{'─'*70}")
    for d in results:
        score = d.get("abuseConfidenceScore",0)
        c = red if score>75 else yellow if score>25 else green
        print(f"{cyan(d.get('ipAddress','?')):20s} {d.get('countryCode','??'):6s} {c(f'{score:3d}%'):7s} {str(d.get('totalReports',0)):8s} {d.get('isp','?')[:30]}")

# ─── HEURISTIC ENGINE ─────────────────────────────────────────────────────────
SIGNATURES = [
    # ── Ransomware ──────────────────────────────────────────────────────────
    {"id":"RW001","family":"Ransomware","name":"Shadow Copy Deletion","severity":"CRITICAL","tactic":"T1490",
     "pattern":r"vssadmin\s+delete\s+shadows|wmic\s+shadowcopy\s+delete|bcdedit.*recoveryenabled\s+no"},
    {"id":"RW002","family":"Ransomware","name":"Ransomware Extension","severity":"CRITICAL","tactic":"T1486",
     "pattern":r"\.(locked|encrypted|crypt|ransom|pay2decrypt|enc|wcry|wncry|zepto|locky|cerber)\b"},
    {"id":"RW003","family":"Ransomware","name":"Ransom Note","severity":"HIGH","tactic":"T1486",
     "pattern":r"YOUR_FILES_ARE_ENCRYPTED|HOW_TO_DECRYPT|README_FOR_DECRYPT|DECRYPT_INSTRUCTION|how to recover files"},
    {"id":"RW004","family":"Ransomware","name":"Backup Destruction","severity":"CRITICAL","tactic":"T1490",
     "pattern":r"wbadmin\s+delete|ntbackup.*\/delete"},
    # ── RAT / C2 ─────────────────────────────────────────────────────────────
    {"id":"RAT001","family":"RAT","name":"Encoded PowerShell","severity":"HIGH","tactic":"T1059.001",
     "pattern":r"-[Ee]nc(odedCommand)?\s+[A-Za-z0-9+/]{20,}|powershell.*-w\s*hidden.*-ep\s*bypass"},
    {"id":"RAT002","family":"RAT","name":"Unix Reverse Shell","severity":"CRITICAL","tactic":"T1059.004",
     "pattern":r"bash\s+-i.*>&.*\/dev\/tcp|nc\s+-e.*\/bin\/(ba)?sh|socat.*exec.*sh"},
    {"id":"RAT004","family":"CobaltStrike","name":"CS Shellcode","severity":"CRITICAL","tactic":"T1055",
     "pattern":r"ReflectiveDLL|SetThreadContext.*shellcode|\bbeacon\.(x64|x86)\b"},
    # ── Credential Theft ──────────────────────────────────────────────────────
    {"id":"CRED001","family":"Stealer","name":"LSASS Dump","severity":"CRITICAL","tactic":"T1003.001",
     "pattern":r"lsass\.dmp|MiniDumpWriteDump.*lsass|procdump.*lsass|sekurlsa::logonpasswords"},
    {"id":"CRED002","family":"Stealer","name":"Mimikatz","severity":"CRITICAL","tactic":"T1003",
     "pattern":r"mimikatz|privilege::debug|sekurlsa::|kerberos::ptt|lsadump::"},
    {"id":"CRED003","family":"Stealer","name":"Browser Creds","severity":"HIGH","tactic":"T1555.003",
     "pattern":r"Login Data.*sqlite|key4\.db|logins\.json.*firefox|Chrome.*Local State.*encrypted"},
    {"id":"CRED004","family":"Stealer","name":"SAM Extraction","severity":"CRITICAL","tactic":"T1003.002",
     "pattern":r"reg\s+save.*HKLM.*SAM|reg\s+save.*SYSTEM|samdump|secretsdump"},
    # ── Persistence ───────────────────────────────────────────────────────────
    {"id":"PER001","family":"Persistence","name":"Registry Run Key","severity":"HIGH","tactic":"T1547.001",
     "pattern":r"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run|HKLM.*CurrentVersion\\Run"},
    {"id":"PER002","family":"Persistence","name":"Scheduled Task","severity":"HIGH","tactic":"T1053.005",
     "pattern":r"schtasks.*\/create|Register-ScheduledTask|New-ScheduledTask"},
    {"id":"PER003","family":"Persistence","name":"WMI Subscription","severity":"HIGH","tactic":"T1546.003",
     "pattern":r"EventFilter.*WMI|__EventFilter|ActiveScriptEventConsumer|CommandLineEventConsumer"},
    # ── Evasion ───────────────────────────────────────────────────────────────
    {"id":"EVA001","family":"Evasion","name":"AMSI Bypass","severity":"HIGH","tactic":"T1562.001",
     "pattern":r"amsiInitFailed|AmsiScanBuffer.*patch|amsi\.dll.*WriteProcessMemory"},
    {"id":"EVA002","family":"Evasion","name":"ETW Patching","severity":"HIGH","tactic":"T1562.006",
     "pattern":r"EtwEventWrite.*patch|ntdll.*EtwEventWrite.*xor"},
    {"id":"EVA003","family":"Evasion","name":"Sandbox Detection","severity":"MEDIUM","tactic":"T1497",
     "pattern":r"VBOX|VMWARE|QEMU|SbieDll|SandboxDetect"},
    {"id":"EVA004","family":"Evasion","name":"Process Injection","severity":"CRITICAL","tactic":"T1055",
     "pattern":r"CreateRemoteThread|NtCreateThreadEx|RtlCreateUserThread|QueueUserAPC.*inject"},
    {"id":"EVA005","family":"Evasion","name":"Process Hollowing","severity":"CRITICAL","tactic":"T1055.012",
     "pattern":r"NtUnmapViewOfSection|ZwUnmapViewOfSection|CreateProcess.*SUSPENDED.*WriteProcessMemory"},
    # ── Network ───────────────────────────────────────────────────────────────
    {"id":"NET001","family":"C2","name":"DNS Tunneling","severity":"HIGH","tactic":"T1071.004",
     "pattern":r"iodine|dnscat|dns2tcp|SocksPort.*9050"},
    {"id":"NET002","family":"C2","name":"Tor Network","severity":"HIGH","tactic":"T1090.003",
     "pattern":r"\.onion|SocksPort.*9050|127\.0\.0\.1:9050"},
    # ── Obfuscation ───────────────────────────────────────────────────────────
    {"id":"OBF001","family":"Obfuscation","name":"Large Base64 Blob","severity":"MEDIUM","tactic":"T1027",
     "pattern":r"[A-Za-z0-9+/]{100,}={0,2}"},
    {"id":"OBF002","family":"Obfuscation","name":"VBA Macro","severity":"HIGH","tactic":"T1027",
     "pattern":r"Auto(Open|Exec|Close|New)|Document_Open|Shell\s*\(|Chr\(\d+\).*&.*Chr\("},
    # ── Exfiltration ─────────────────────────────────────────────────────────
    {"id":"EXF001","family":"Exfiltration","name":"Data Compression","severity":"HIGH","tactic":"T1560.001",
     "pattern":r"Compress-Archive.*temp|7z\s+a\s+-p|rar\s+a\s+-hp"},
    {"id":"EXF003","family":"Exfiltration","name":"Cloud Upload","severity":"MEDIUM","tactic":"T1567",
     "pattern":r"mega\.nz|anonfiles|transfer\.sh|gofile\.io"},
    # ── Phishing ─────────────────────────────────────────────────────────────
    {"id":"PHI002","family":"Phishing","name":"HTML Smuggling","severity":"HIGH","tactic":"T1027.006",
     "pattern":r"new\s+Blob.*application\/octet|msSaveBlob|createObjectURL.*Blob.*click"},
]

def compute_entropy(data: bytes) -> float:
    if not data: return 0.0
    freq = [0]*256
    for b in data: freq[b] += 1
    return -sum((c/len(data))*math.log2(c/len(data)) for c in freq if c > 0)

def run_heuristic(text: str, filepath: str = None):
    header("HEURISTIC ENGINE", filepath or "<text input>")

    hits = []
    weights = {"CRITICAL":40, "HIGH":20, "MEDIUM":8, "LOW":2}

    for sig in SIGNATURES:
        if re.search(sig["pattern"], text, re.IGNORECASE):
            hits.append(sig)

    score = min(100, sum(weights.get(h["severity"],0) for h in hits))
    verdict = "MALICIOUS" if score>=60 else "SUSPICIOUS" if score>=30 else "POTENTIALLY_UNWANTED" if score>=10 else "CLEAN"

    verdict_color = red if verdict=="MALICIOUS" else yellow if verdict in ("SUSPICIOUS","POTENTIALLY_UNWANTED") else green
    print(f"  {bold('Signatures Scanned')} {len(SIGNATURES)}")
    print(f"  {bold('Signatures Matched')} {len(hits)}")
    print()

    # Score bar
    bar = "█" * int(score/2.5) + "░" * (40-int(score/2.5))
    print(f"  {bold('Risk Score')} [{verdict_color(bar)}] {verdict_color(bold(f'{score}/100'))}")
    print(f"  {bold('Verdict')   } {verdict_color(bold(verdict))}")

    # Entropy if file
    if filepath and Path(filepath).exists():
        try:
            data = Path(filepath).read_bytes()
            ent = compute_entropy(data)
            ent_color = red if ent>7.5 else yellow if ent>6.5 else green
            print(f"  {bold('File Entropy')} {ent_color(f'{ent:.4f}/8.0')} {'[HIGH — packed/encrypted]' if ent>7.0 else ''}")
        except: pass

    # Family breakdown
    families = {}
    for h in hits:
        families[h["family"]] = families.get(h["family"],0)+1
    if families:
        print(f"\n  {bold('Families Detected')}")
        for fam, cnt in sorted(families.items(), key=lambda x:-x[1]):
            print(f"  {yellow('⬥'):3s} {fam:25s} ×{cnt}")

    # Detailed hits
    if hits:
        print(f"\n  {bold('Signature Matches')}")
        sev_order = {"CRITICAL":0,"HIGH":1,"MEDIUM":2,"LOW":3}
        for h in sorted(hits, key=lambda x: sev_order.get(x["severity"],9)):
            sev_color = red if h["severity"]=="CRITICAL" else yellow if h["severity"]=="HIGH" else cyan
            print(f"\n  {sev_color(bold(h['id']))} {bold(h['name'])}")
            print(f"  {D}Family: {h['family']}  Severity: {h['severity']}  MITRE: {h['tactic']}{N}")
    else:
        print(f"\n  {green('No signatures matched — content appears clean')}")

    return {"hits": hits, "score": score, "verdict": verdict, "families": families}

# ─── CLI ENTRY ────────────────────────────────────────────────────────────────
def configure_keys():
    print(f"\n{P}{B}KILLBOX Key Configuration{N}")
    cfg = load_config()
    print("Press Enter to keep existing value.")
    for key, label, hint in [
        ("claude_api_key","Anthropic Claude API Key","console.anthropic.com"),
        ("vt_api_key","VirusTotal API Key","virustotal.com/gui/my-apikey"),
        ("abuse_api_key","AbuseIPDB API Key","abuseipdb.com/account/api"),
    ]:
        current = cfg.get(key,"")
        masked = f"...{current[-8:]}" if current else "(not set)"
        val = input(f"  {label} [{masked}] ({hint}): ").strip()
        if val: cfg[key] = val
    save_config(cfg)
    print(green("  ✓ Keys saved to /opt/killbox/config.json"))

def main():
    parser = argparse.ArgumentParser(prog="kb-enrich", description="KILLBOX Threat Enrichment")
    parser.add_argument("--configure", action="store_true", help="Configure API keys")
    sub = parser.add_subparsers(dest="cmd")

    p_vt = sub.add_parser("vt", help="VirusTotal lookups")
    p_vt.add_argument("type", choices=["hash","url","domain","ip"])
    p_vt.add_argument("target")

    p_ab = sub.add_parser("abuse", help="AbuseIPDB check")
    p_ab.add_argument("target", help="IP or path to file with IPs")
    p_ab.add_argument("--bulk", action="store_true")

    p_h = sub.add_parser("heuristic", help="Run heuristic engine")
    p_h.add_argument("target", help="File path or - for stdin")

    args = parser.parse_args()

    if args.configure or not args.cmd:
        configure_keys(); return

    if args.cmd == "vt":
        key = get_key("vt")
        if not key: print(red("✗ VT API key not set. Run: kb-enrich --configure")); sys.exit(1)
        {"hash":vt_hash,"url":vt_url,"domain":vt_domain,"ip":vt_ip}[args.type](args.target, key)

    elif args.cmd == "abuse":
        key = get_key("abuse")
        if not key: print(red("✗ AbuseIPDB key not set. Run: kb-enrich --configure")); sys.exit(1)
        if args.bulk or Path(args.target).exists():
            ips = Path(args.target).read_text().split() if Path(args.target).exists() else [args.target]
            abuse_bulk([ip.strip() for ip in ips if ip.strip()], key)
        else:
            abuse_check(args.target, key)

    elif args.cmd == "heuristic":
        if args.target == "-":
            text = sys.stdin.read()
            run_heuristic(text)
        else:
            p = Path(args.target)
            if not p.exists(): print(red(f"✗ File not found: {args.target}")); sys.exit(1)
            try: text = p.read_text(errors="replace")
            except: text = ""
            run_heuristic(text, str(p))

if __name__ == "__main__":
    main()
