import { useState, useRef, useCallback, useEffect } from "react";

// ─── CONSTANTS ────────────────────────────────────────────────────────────────
const MODEL = "claude-sonnet-4-20250514";
const MAX_TOKENS = 4000;
const VT_API_BASE   = "https://www.virustotal.com/api/v3";
const ABUSE_API_BASE = "https://api.abuseipdb.com/api/v2";

const MODULES = [
  { id: "static",     label: "Static Analysis",   icon: "⬡" },
  { id: "email",      label: "Email Forensics",    icon: "✉" },
  { id: "behavioral", label: "Behavioral Intel",   icon: "◈" },
  { id: "network",    label: "Network IOCs",       icon: "⬢" },
  { id: "yara",       label: "YARA Generator",     icon: "◉" },
  { id: "threat",     label: "Threat Hunt",        icon: "◎" },
  { id: "vt",         label: "VirusTotal",         icon: "⬛" },
  { id: "abuse",      label: "AbuseIPDB",          icon: "◍" },
  { id: "heuristic",  label: "Heuristic Engine",   icon: "◬" },
];

// ─── HEURISTIC SIGNATURES ─────────────────────────────────────────────────────
// Local signature + heuristic detection engine — runs fully in-browser
const SIGNATURES = [
  // ── Ransomware ──────────────────────────────────────────────────────────────
  { id: "RW001", family: "Ransomware", name: "Shadow Copy Deletion",     severity: "CRITICAL",
    pattern: /vssadmin\s+delete\s+shadows|wmic\s+shadowcopy\s+delete|bcdedit.*recoveryenabled\s+no/i,
    tactic: "T1490", desc: "Shadow copy deletion — common ransomware pre-encryption step" },
  { id: "RW002", family: "Ransomware", name: "File Extension Mass Rename", severity: "CRITICAL",
    pattern: /\.(locked|encrypted|crypt|ransom|pay2decrypt|enc|wcry|wncry|zepto|locky|cerber)/i,
    tactic: "T1486", desc: "Ransomware file extension markers detected" },
  { id: "RW003", family: "Ransomware", name: "Ransom Note Artifact",      severity: "HIGH",
    pattern: /YOUR_FILES_ARE_ENCRYPTED|HOW_TO_DECRYPT|README_FOR_DECRYPT|DECRYPT_INSTRUCTION|!!! READ ME !!!|how to recover/i,
    tactic: "T1486", desc: "Ransom note string pattern found" },
  { id: "RW004", family: "Ransomware", name: "Backup Destruction",        severity: "CRITICAL",
    pattern: /wbadmin\s+delete|ntbackup.*\/delete|ren.*\.bak\s|del.*backup/i,
    tactic: "T1490", desc: "Backup destruction commands" },

  // ── RAT / C2 ─────────────────────────────────────────────────────────────────
  { id: "RAT001", family: "RAT", name: "Remote Shell Command",            severity: "HIGH",
    pattern: /cmd\.exe.*\/c|powershell.*-enc|-encodedcommand|iex\s*\(|invoke-expression/i,
    tactic: "T1059.001", desc: "Encoded or obfuscated command execution" },
  { id: "RAT002", family: "RAT", name: "Reverse Shell Pattern",           severity: "CRITICAL",
    pattern: /bash\s+-i.*>&.*\/dev\/tcp|nc\s+-e.*\/bin\/(ba)?sh|ncat.*-e|socat.*exec.*sh/i,
    tactic: "T1059.004", desc: "Unix reverse shell pattern" },
  { id: "RAT003", family: "RAT", name: "C2 Beacon User-Agent",            severity: "HIGH",
    pattern: /Mozilla\/5\.0\s\(compatible;\s*(MSIE|Windows NT)[^)]+\)\s*$/i,
    tactic: "T1071.001", desc: "Suspicious/minimal HTTP User-Agent string (C2 beacon)" },
  { id: "RAT004", family: "CobaltStrike", name: "Cobalt Strike Shellcode",severity: "CRITICAL",
    pattern: /4d5a.*fc4883e4f0e8cc000000|ReflectiveDLL|SetThreadContext.*shellcode|\bbeacon\.(x64|x86)\b/i,
    tactic: "T1055", desc: "Cobalt Strike beacon or reflective DLL injection" },
  { id: "RAT005", family: "RAT", name: "Sliver/Havoc C2 Framework",       severity: "CRITICAL",
    pattern: /SliverC2|HavocC2|implant_config|grpc.*443.*beacon|demon\.dll/i,
    tactic: "T1071", desc: "Sliver or Havoc C2 framework indicators" },

  // ── Credential Theft ─────────────────────────────────────────────────────────
  { id: "CRED001", family: "Stealer", name: "LSASS Dump",                 severity: "CRITICAL",
    pattern: /lsass\.dmp|MiniDumpWriteDump.*lsass|procdump.*lsass|sekurlsa::logonpasswords|sekurlsa::wdigest/i,
    tactic: "T1003.001", desc: "LSASS memory dumping — credential extraction" },
  { id: "CRED002", family: "Stealer", name: "Mimikatz Artifacts",         severity: "CRITICAL",
    pattern: /mimikatz|privilege::debug|sekurlsa::|kerberos::ptt|lsadump::|dpapi::/i,
    tactic: "T1003", desc: "Mimikatz command or output pattern" },
  { id: "CRED003", family: "Stealer", name: "Browser Credential Theft",   severity: "HIGH",
    pattern: /Login Data.*sqlite|key4\.db|logins\.json.*firefox|Chrome.*Local State.*encrypted/i,
    tactic: "T1555.003", desc: "Browser credential store access pattern" },
  { id: "CRED004", family: "Stealer", name: "SAM Database Extraction",    severity: "CRITICAL",
    pattern: /reg\s+save.*HKLM.*SAM|reg\s+save.*SYSTEM|impacket.*secretsdump|samdump/i,
    tactic: "T1003.002", desc: "SAM hive extraction attempt" },
  { id: "CRED005", family: "Stealer", name: "Clipboard Monitor",          severity: "MEDIUM",
    pattern: /GetClipboardData|OpenClipboard|clipboard.*crypto.*wallet|clipboard.*monitor/i,
    tactic: "T1115", desc: "Clipboard monitoring — may target crypto wallets" },

  // ── Persistence ───────────────────────────────────────────────────────────────
  { id: "PER001", family: "Persistence", name: "Registry Run Key",        severity: "HIGH",
    pattern: /HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run|HKLM.*CurrentVersion\\Run/i,
    tactic: "T1547.001", desc: "Registry run key persistence" },
  { id: "PER002", family: "Persistence", name: "Scheduled Task Creation", severity: "HIGH",
    pattern: /schtasks.*\/create|at\s+\d+:\d+|Register-ScheduledTask|New-ScheduledTask/i,
    tactic: "T1053.005", desc: "Scheduled task created for persistence" },
  { id: "PER003", family: "Persistence", name: "WMI Subscription",        severity: "HIGH",
    pattern: /EventFilter.*WMI|__EventFilter|ActiveScriptEventConsumer|CommandLineEventConsumer/i,
    tactic: "T1546.003", desc: "WMI event subscription persistence" },
  { id: "PER004", family: "Persistence", name: "DLL Hijacking Path",      severity: "MEDIUM",
    pattern: /C:\\Windows\\Temp\\.*\.dll|%APPDATA%.*system32|\.dll.*side.?load/i,
    tactic: "T1574.001", desc: "DLL placed in unusual location — hijacking candidate" },
  { id: "PER005", family: "Persistence", name: "Startup Folder Drop",     severity: "HIGH",
    pattern: /Startup\\.*\.(exe|bat|vbs|ps1|lnk)|Start Menu\\Programs\\Startup/i,
    tactic: "T1547.001", desc: "File written to startup folder" },

  // ── Evasion ───────────────────────────────────────────────────────────────────
  { id: "EVA001", family: "Evasion", name: "AMSI Bypass",                 severity: "HIGH",
    pattern: /amsiInitFailed|AmsiScanBuffer.*patch|amsi\.dll.*WriteProcessMemory|[Rr]eflection.*amsi/i,
    tactic: "T1562.001", desc: "AMSI bypass technique detected" },
  { id: "EVA002", family: "Evasion", name: "ETW Patching",                severity: "HIGH",
    pattern: /EtwEventWrite.*patch|ntdll.*EtwEventWrite.*xor|EventWrite.*disable/i,
    tactic: "T1562.006", desc: "ETW (Event Tracing for Windows) disabled" },
  { id: "EVA003", family: "Evasion", name: "Sandbox Detection",           severity: "MEDIUM",
    pattern: /VBOX|VMWARE|QEMU|VIRTUAL|SbieDll|SandboxDetect|IsDebuggerPresent.*CheckRemoteDebugger/i,
    tactic: "T1497", desc: "Sandbox or VM detection technique" },
  { id: "EVA004", family: "Evasion", name: "Process Injection",           severity: "CRITICAL",
    pattern: /CreateRemoteThread|NtCreateThreadEx|RtlCreateUserThread|QueueUserAPC.*inject|SetWindowsHookEx/i,
    tactic: "T1055", desc: "Process injection API sequence" },
  { id: "EVA005", family: "Evasion", name: "Process Hollowing",           severity: "CRITICAL",
    pattern: /NtUnmapViewOfSection|ZwUnmapViewOfSection|CreateProcess.*SUSPENDED.*WriteProcessMemory/i,
    tactic: "T1055.012", desc: "Process hollowing (RunPE) technique" },
  { id: "EVA006", family: "Evasion", name: "Timestomping",                severity: "MEDIUM",
    pattern: /SetFileTime|NtSetInformationFile.*FileBasicInformation|timestomp/i,
    tactic: "T1070.006", desc: "File timestamp manipulation" },

  // ── Network ───────────────────────────────────────────────────────────────────
  { id: "NET001", family: "C2", name: "DNS Tunneling",                    severity: "HIGH",
    pattern: /iodine|dnscat|dns2tcp|dns.*\.base64\.|TXT.*record.*exfil/i,
    tactic: "T1071.004", desc: "DNS tunneling tool or pattern" },
  { id: "NET002", family: "C2", name: "Tor Hidden Service",               severity: "HIGH",
    pattern: /\.onion|torrc|Tor Browser|SocksPort.*9050|127\.0\.0\.1:9050/i,
    tactic: "T1090.003", desc: "Tor network communication" },
  { id: "NET003", family: "C2", name: "HTTP Beacon Pattern",              severity: "HIGH",
    pattern: /sleep\(\d{4,6}\).*http|beacon.*interval|check.?in.*minutes|\/jquery.*\.js.*POST/i,
    tactic: "T1071.001", desc: "C2 HTTP beacon sleep/checkin pattern" },
  { id: "NET004", family: "C2", name: "Pastebin / Paste C2",              severity: "MEDIUM",
    pattern: /pastebin\.com\/raw\/|hastebin\.com|paste\.ee|controlc\.com|ghostbin/i,
    tactic: "T1102", desc: "C2 via paste service — dead drop resolver" },

  // ── Obfuscation ───────────────────────────────────────────────────────────────
  { id: "OBF001", family: "Obfuscation", name: "Base64 Payload",          severity: "MEDIUM",
    pattern: /[A-Za-z0-9+/]{100,}={0,2}/,
    tactic: "T1027", desc: "Large base64 blob — likely encoded payload" },
  { id: "OBF002", family: "Obfuscation", name: "PowerShell Encoded Cmd",  severity: "HIGH",
    pattern: /-[Ee]nc(odedCommand)?\s+[A-Za-z0-9+/]{20,}|powershell.*-w\s*hidden.*-ep\s*bypass/i,
    tactic: "T1027", desc: "PowerShell encoded/obfuscated command" },
  { id: "OBF003", family: "Obfuscation", name: "XOR Obfuscation",         severity: "MEDIUM",
    pattern: /\bxor\b.*key|xor_key\s*=|[0-9a-f]{2}(\s*\^\s*[0-9a-f]{2}){5,}|for.*xor.*0x[0-9a-f]/i,
    tactic: "T1027", desc: "XOR-based obfuscation pattern" },
  { id: "OBF004", family: "Obfuscation", name: "VBA Macro Obfuscation",   severity: "HIGH",
    pattern: /Auto(Open|Exec|Close|New)|Document_Open|Shell\s*\(|Chr\(\d+\).*&.*Chr\(|Environ\s*\(/i,
    tactic: "T1564", desc: "Obfuscated VBA macro pattern" },

  // ── Exfiltration ─────────────────────────────────────────────────────────────
  { id: "EXF001", family: "Exfiltration", name: "Data Staging",           severity: "HIGH",
    pattern: /Compress-Archive.*temp|7z\s+a\s+-p|rar\s+a\s+-hp|tar.*czf.*\/tmp/i,
    tactic: "T1560.001", desc: "Data compressed for exfiltration" },
  { id: "EXF002", family: "Exfiltration", name: "HTTPS Exfil POST",       severity: "HIGH",
    pattern: /curl.*-F.*@|Invoke-WebRequest.*-Method\s+POST.*-Body|WebClient.*UploadData/i,
    tactic: "T1041", desc: "Data exfiltration via HTTP POST" },
  { id: "EXF003", family: "Exfiltration", name: "Cloud Storage Abuse",    severity: "MEDIUM",
    pattern: /mega\.nz|anonfiles|transfer\.sh|gofile\.io|ufile\.io.*upload/i,
    tactic: "T1567", desc: "Exfiltration to cloud/file sharing service" },

  // ── Email Phishing ────────────────────────────────────────────────────────────
  { id: "PHI001", family: "Phishing", name: "Homograph Domain",           severity: "HIGH",
    pattern: /xn--[a-z0-9-]{4,}|[\u0430-\u044f\u00e0-\u00ff]{2,}.*\.(com|net|org|io)/,
    tactic: "T1566.002", desc: "Possible IDN homograph attack — unicode lookalike domain" },
  { id: "PHI002", family: "Phishing", name: "HTML Smuggling",             severity: "HIGH",
    pattern: /new\s+Blob.*application\/octet|msSaveBlob|createObjectURL.*Blob.*click/i,
    tactic: "T1027.006", desc: "HTML smuggling technique for payload delivery" },
  { id: "PHI003", family: "Phishing", name: "Credential Harvesting Page", severity: "HIGH",
    pattern: /document\.forms.*submit|document\.getElementById.*password.*value|fetch.*credentials|action.*login.*post/i,
    tactic: "T1056.003", desc: "Web credential harvesting form pattern" },
];

// ─── HEURISTIC SCORING ENGINE ─────────────────────────────────────────────────
function runHeuristicEngine(text) {
  if (!text || text.length < 10) return { hits: [], score: 0, verdict: "CLEAN", summary: [] };

  const hits = [];
  for (const sig of SIGNATURES) {
    if (sig.pattern.test(text)) hits.push(sig);
  }

  // Score calculation
  const weights = { CRITICAL: 40, HIGH: 20, MEDIUM: 8, LOW: 2 };
  const rawScore = hits.reduce((s, h) => s + (weights[h.severity] || 0), 0);
  const score = Math.min(100, rawScore);

  // Composite verdict
  const verdict =
    score >= 60 ? "MALICIOUS" :
    score >= 30 ? "SUSPICIOUS" :
    score >= 10 ? "POTENTIALLY_UNWANTED" : "CLEAN";

  // Family breakdown
  const families = {};
  for (const h of hits) {
    families[h.family] = (families[h.family] || 0) + 1;
  }

  return { hits, score, verdict, families };
}

// ─── SYSTEM PROMPTS ───────────────────────────────────────────────────────────
const SYSTEM_PROMPTS = {
  static: `You are KILLBOX/STATIC — a world-class malware reverse engineer and binary analyst.
Analyze the provided content with surgical precision. Extract:
1. **File Signature & Magic Bytes** — identify format, packer, or obfuscation
2. **Entropy Analysis** — flag high-entropy sections (packed/encrypted payloads)
3. **Suspicious Strings** — C2 domains, IPs, registry keys, file paths, mutex names, API calls
4. **PE Header Anomalies** (if applicable) — section names, import table, TLS callbacks, overlay data
5. **Embedded Artifacts** — base64, hex blobs, shellcode patterns
6. **Obfuscation Techniques** — XOR keys, ROT ciphers, custom encoders, dead code insertion
7. **MITRE ATT&CK Techniques** — map behaviors to TTPs with technique IDs
8. **Threat Classification** — RAT / Stealer / Ransomware / Dropper / Loader / Wiper / Rootkit
Format as structured threat intel report. Be direct, precise, actionable. Use technical terminology.`,
  email: `You are KILLBOX/MAILSEC — an elite email threat analyst and phishing forensics expert.
Analyze the provided email content/headers with deep forensic rigor:
1. **Header Forensics** — SPF/DKIM/DMARC validation results, received chain anomalies, X-Originating-IP
2. **Sender Spoofing** — display name deception, lookalike domains, unicode homoglyph attacks
3. **Social Engineering Vectors** — urgency triggers, authority impersonation, fear/reward manipulation
4. **Payload Analysis** — malicious attachment types, embedded macros, HTML smuggling, QR code phishing
5. **URL & Link Analysis** — redirectors, URL shorteners, typosquatting, IDN homograph attacks
6. **Infrastructure IOCs** — sending IPs, domains, mail servers, CDN abuse
7. **Campaign Attribution** — BEC / Spear-phishing / Mass phishing / APT / Ransomware delivery
8. **MITRE ATT&CK PRE-ATT&CK TTPs** — reconnaissance, resource development, initial access techniques
9. **Recommended Defensive Actions** — mail gateway rules, user awareness alerts
Be forensically precise. Extract every IOC.`,
  behavioral: `You are KILLBOX/BEHAV — a dynamic malware analyst specializing in behavioral intelligence.
Given indicators, code snippets, or descriptions, deduce:
1. **Execution Chain** — dropper → loader → payload sequence
2. **Persistence Mechanisms** — registry run keys, scheduled tasks, WMI subscriptions, DLL hijacking
3. **Privilege Escalation Paths** — UAC bypass, token manipulation, exploit chains
4. **Defense Evasion** — AMSI bypass, ETW patching, sandbox detection, VM/debugger evasion
5. **Credential Access** — LSASS dumping, SAM extraction, Kerberoasting, token theft
6. **Lateral Movement** — pass-the-hash, WMI execution, PSExec, RDP hijacking
7. **Data Exfiltration Methods** — C2 protocol, staging, compression, encryption before exfil
8. **Kill Chain Stage** — Recon/Weapon/Delivery/Exploit/Install/C2/Actions
9. **Hunting Hypothesis** — Sigma/Sysmon rule concepts
Map everything to MITRE ATT&CK Enterprise.`,
  network: `You are KILLBOX/NETOPS — a network threat intelligence analyst and C2 infrastructure hunter.
Analyze provided IPs, domains, URLs, PCAP snippets, or traffic descriptions:
1. **C2 Protocol Identification** — HTTP/HTTPS beacon, DNS tunneling, ICMP covert channels
2. **Beacon Analysis** — jitter, check-in intervals, URI structures, user-agent anomalies
3. **Infrastructure Profiling** — ASN, hosting provider, GeoIP, certificate analysis
4. **DGA Detection** — seed analysis, algorithm fingerprinting
5. **Known C2 Signatures** — Cobalt Strike, Metasploit, Sliver, Brute Ratel, Havoc
6. **Firewall/IDS Rules** — Suricata/Snort rule syntax
7. **Passive DNS & WHOIS** — registration patterns, infrastructure reuse
Deliver actionable IOCs with confidence scores.`,
  yara: `You are KILLBOX/YARAGEN — an expert YARA rule engineer.
Based on samples, IOCs, or behavioral descriptions, generate:
1. **Comprehensive YARA Rules** — meta (author, description, hash, date, severity)
2. **String Detection** — hex patterns, ASCII/wide strings, regex
3. **Condition Logic** — filesize, magic bytes, string counts, offset anchoring
4. **Multiple Variants** — high-confidence + heuristic rules
5. **PE-Specific Rules** — import hashes, section characteristics
6. **Memory Scanning Rules** — injected code, unpacked payloads
Format in clean YARA syntax, ready for deployment.`,
  threat: `You are KILLBOX/THREAT — a strategic threat intelligence analyst.
Analyze for:
1. **Threat Actor Attribution** — APT group, criminal syndicate, nation-state nexus
2. **Confidence Assessment** — evidence chains
3. **Campaign Timeline** — tooling evolution, infrastructure patterns
4. **Targeting Profile** — victimology, sectors, geographic focus
5. **Diamond Model** — adversary/capability/infrastructure/victim
6. **Predictive Assessment** — likely next actions
Synthesize with analytical rigor.`,
  vt: `You are KILLBOX/VT-ANALYST — a VirusTotal intelligence specialist.
Given VirusTotal API results (JSON), produce a deep threat intelligence report:
1. **Detection Summary** — engines that flagged, consensus family name, detection rate
2. **AV Verdict Aggregation** — group by family, flag disagreements or partial matches
3. **Behavioral Summary** — sandbox behavior: network, file, registry, process activity
4. **MITRE ATT&CK Mapping** — from sandbox behaviors
5. **Infrastructure IOCs** — contacted IPs, domains, URLs, dropped files
6. **Crowdsourced Context** — community tags, threat categories, campaigns
7. **Historic Context** — first/last seen, submission count, reputation score
8. **Threat Classification** — final verdict with confidence
Be precise. Quote specific engine detections where relevant.`,
  abuse: `You are KILLBOX/ABUSEIPDB — an IP threat intelligence analyst.
Given AbuseIPDB API results (JSON), produce a comprehensive IP threat report:
1. **Abuse Confidence Score** — interpret the score with context
2. **Attack Category Breakdown** — classify reported attack types (SSH brute force, spam, DDoS, etc.)
3. **Geolocation & Infrastructure** — country, ISP, ASN, hosting type
4. **Historical Activity** — total reports, report frequency, first/last seen
5. **Contextual Threat Assessment** — Tor exit node, VPN, proxy, cloud/datacenter
6. **IOC Verdict** — block/monitor/watchlist recommendation with justification
7. **Correlated Indicators** — suggest pivoting to related infrastructure
Deliver actionable threat intelligence with defensive recommendations.`,
  heuristic: `You are KILLBOX/HEUR — a heuristic malware classification expert.
Given heuristic scan results from KILLBOX's built-in signature engine plus raw content:
1. **Heuristic Verdict Analysis** — evaluate confidence of automated detections
2. **False Positive Assessment** — flag potential FPs, explain why
3. **Technique Chaining** — identify how detected TTPs combine into an attack chain
4. **Severity Contextualization** — explain why certain detections matter more in this context
5. **Coverage Gaps** — what heuristics couldn't detect that a human analyst should check
6. **Recommended Next Steps** — specific follow-up analysis actions
7. **Detection Rule Suggestions** — Sigma/YARA/Snort rules based on findings
Synthesize heuristic output with deep analytical expertise.`,
};

// ─── UTILS ────────────────────────────────────────────────────────────────────
const formatTs = () => new Date().toISOString().replace("T"," ").substring(0,19) + " UTC";
const genSession = () => "KB-" + Math.random().toString(36).slice(2,10).toUpperCase();

// ─── COMPONENT: TerminalLine ──────────────────────────────────────────────────
function TerminalLine({ children, type = "info", delay = 0 }) {
  const [vis, setVis] = useState(delay === 0);
  useEffect(() => { if(delay>0){const t=setTimeout(()=>setVis(true),delay);return()=>clearTimeout(t);} },[delay]);
  const c={info:"#7dd3fc",success:"#4ade80",warn:"#fbbf24",error:"#f87171",dim:"#6b7280",accent:"#e879f9",data:"#a5f3fc"};
  return <div style={{opacity:vis?1:0,transition:"opacity 0.3s",color:c[type]||c.info,fontFamily:"'Courier New',monospace",fontSize:"11px",lineHeight:"1.6",padding:"1px 0"}}>{children}</div>;
}

function ScannerBar({ active }) {
  return (
    <div style={{position:"relative",height:"2px",background:"#1a1a2e",overflow:"hidden",margin:"6px 0"}}>
      {active&&<div style={{position:"absolute",top:0,left:0,height:"100%",width:"30%",background:"linear-gradient(90deg,transparent,#e879f9,#7c3aed,transparent)",animation:"scan 1.5s linear infinite"}}/>}
      <style>{`@keyframes scan{0%{left:-30%}100%{left:110%}}`}</style>
    </div>
  );
}

function ThreatBadge({ level }) {
  const cfg={CRITICAL:{bg:"#450a0a",br:"#ef4444",tx:"#fca5a5"},HIGH:{bg:"#431407",br:"#f97316",tx:"#fdba74"},MEDIUM:{bg:"#422006",br:"#f59e0b",tx:"#fde68a"},LOW:{bg:"#052e16",br:"#22c55e",tx:"#86efac"},CLEAN:{bg:"#052e16",br:"#22c55e",tx:"#86efac"},INFO:{bg:"#0c1a2e",br:"#3b82f6",tx:"#93c5fd"},SUSPICIOUS:{bg:"#431407",br:"#f97316",tx:"#fdba74"},MALICIOUS:{bg:"#450a0a",br:"#ef4444",tx:"#fca5a5"},POTENTIALLY_UNWANTED:{bg:"#422006",br:"#f59e0b",tx:"#fde68a"}};
  const c=cfg[level]||cfg.INFO;
  return <span style={{background:c.bg,border:`1px solid ${c.br}`,color:c.tx,padding:"2px 10px",borderRadius:"2px",fontSize:"10px",fontFamily:"'Courier New',monospace",fontWeight:"bold",letterSpacing:"2px",boxShadow:`0 0 8px ${c.br}40`}}>⬥ {level}</span>;
}

// ─── COMPONENT: VT Gauge ──────────────────────────────────────────────────────
function DetectionGauge({ detected, total, label }) {
  const pct = total > 0 ? Math.round((detected / total) * 100) : 0;
  const color = pct > 50 ? "#ef4444" : pct > 20 ? "#f97316" : pct > 5 ? "#f59e0b" : "#22c55e";
  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
        <span style={{ color: "#94a3b8", fontSize: 11 }}>{label}</span>
        <span style={{ color, fontSize: 11, fontWeight: "bold" }}>{detected}/{total} ({pct}%)</span>
      </div>
      <div style={{ height: 6, background: "#0f172a", borderRadius: 0 }}>
        <div style={{ height: "100%", width: `${pct}%`, background: color, transition: "width 0.8s ease", boxShadow: `0 0 6px ${color}80` }} />
      </div>
    </div>
  );
}

// ─── COMPONENT: HeuristicHitCard ──────────────────────────────────────────────
function HeuristicHitCard({ hit }) {
  const colors = { CRITICAL: "#ef4444", HIGH: "#f97316", MEDIUM: "#f59e0b", LOW: "#22c55e" };
  const c = colors[hit.severity] || "#94a3b8";
  return (
    <div style={{ background: "#0a0f1a", border: `1px solid ${c}30`, borderLeft: `3px solid ${c}`, padding: "8px 12px", marginBottom: 6 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 3 }}>
        <span style={{ color: c, fontSize: 11, fontWeight: "bold", letterSpacing: 1 }}>{hit.id} — {hit.name}</span>
        <div style={{ display: "flex", gap: 6 }}>
          <span style={{ color: "#4b5563", fontSize: 10, background: "#0f172a", padding: "1px 6px" }}>{hit.family}</span>
          <span style={{ color: c, fontSize: 10, background: `${c}15`, padding: "1px 6px" }}>{hit.severity}</span>
        </div>
      </div>
      <div style={{ color: "#64748b", fontSize: 11 }}>{hit.desc}</div>
      <div style={{ color: "#374151", fontSize: 10, marginTop: 3 }}>MITRE: <span style={{ color: "#f59e0b" }}>{hit.tactic}</span></div>
    </div>
  );
}

// ─── COMPONENT: ScoreRing ─────────────────────────────────────────────────────
function ScoreRing({ score, verdict }) {
  const color = verdict === "MALICIOUS" ? "#ef4444" : verdict === "SUSPICIOUS" ? "#f97316" : verdict === "POTENTIALLY_UNWANTED" ? "#f59e0b" : "#22c55e";
  const r = 36, circ = 2 * Math.PI * r;
  const offset = circ - (score / 100) * circ;
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
      <svg width={90} height={90} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={45} cy={45} r={r} stroke="#1e293b" strokeWidth={6} fill="none" />
        <circle cx={45} cy={45} r={r} stroke={color} strokeWidth={6} fill="none"
          strokeDasharray={circ} strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 1s ease", filter: `drop-shadow(0 0 4px ${color})` }} />
      </svg>
      <div style={{ marginTop: -76, height: 76, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <div style={{ color, fontSize: 22, fontWeight: "900", fontFamily: "'Courier New',monospace" }}>{score}</div>
        <div style={{ color: "#374151", fontSize: 9, letterSpacing: 1 }}>/ 100</div>
      </div>
      <ThreatBadge level={verdict} />
    </div>
  );
}

// ─── COMPONENT: ResultPanel ───────────────────────────────────────────────────
function ResultPanel({ result, module, sessionId, timestamp }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => { navigator.clipboard.writeText(result); setCopied(true); setTimeout(()=>setCopied(false),2000); };
  const detectLevel = (t) => {
    const u=t.toUpperCase();
    if(u.includes("CRITICAL")||u.includes("RANSOMWARE")||u.includes("WIPER"))return"CRITICAL";
    if(u.includes("HIGH")||u.includes("MALICIOUS")||u.includes("TROJAN"))return"HIGH";
    if(u.includes("MEDIUM")||u.includes("SUSPICIOUS"))return"MEDIUM";
    if(u.includes("LOW")||u.includes("BENIGN"))return"LOW";
    return"INFO";
  };
  return (
    <div style={{background:"#070b14",border:"1px solid #1e293b",borderTop:"2px solid #7c3aed",padding:"20px",marginTop:"16px",fontFamily:"'Courier New',monospace"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"16px",flexWrap:"wrap",gap:8}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <span style={{color:"#7c3aed",fontSize:"10px",letterSpacing:"3px"}}>ANALYSIS COMPLETE</span>
          <ThreatBadge level={detectLevel(result)}/>
        </div>
        <div style={{display:"flex",gap:12,alignItems:"center"}}>
          <span style={{color:"#374151",fontSize:"10px"}}>{sessionId}</span>
          <span style={{color:"#374151",fontSize:"10px"}}>{timestamp}</span>
          <button onClick={handleCopy} style={{background:copied?"#14532d":"#1e293b",border:`1px solid ${copied?"#22c55e":"#374151"}`,color:copied?"#4ade80":"#94a3b8",padding:"4px 12px",fontSize:"10px",cursor:"pointer",letterSpacing:"1px"}}>
            {copied?"✓ COPIED":"⬡ COPY"}
          </button>
        </div>
      </div>
      <ScannerBar active={false}/>
      <div style={{color:"#cbd5e1",fontSize:"13px",lineHeight:"1.8",whiteSpace:"pre-wrap",maxHeight:"500px",overflowY:"auto",paddingRight:8}}
        dangerouslySetInnerHTML={{__html:result
          .replace(/\*\*(.*?)\*\*/g,'<strong style="color:#e879f9">$1</strong>')
          .replace(/`([^`]+)`/g,'<code style="background:#1e293b;color:#7dd3fc;padding:1px 6px;font-size:12px">$1</code>')
          .replace(/^(#{1,3})\s(.+)$/gm,(_,h,t)=>`<div style="color:#7c3aed;font-size:${15-h.length}px;font-weight:bold;margin:10px 0 3px">◈ ${t}</div>`)
          .replace(/^[-•]\s(.+)$/gm,'<div style="padding-left:14px;color:#94a3b8">⬥ $1</div>')
          .replace(/T\d{4}(\.\d{3})?/g,'<span style="color:#f59e0b;font-weight:bold">$&</span>')
          .replace(/\b(\d{1,3}\.){3}\d{1,3}\b/g,'<span style="color:#4ade80">$&</span>')
          .replace(/https?:\/\/\S+/g,'<span style="color:#f87171">$&</span>')
        }}
      />
      <div style={{marginTop:12,paddingTop:8,borderTop:"1px solid #1e293b",display:"flex",justifyContent:"space-between"}}>
        <span style={{color:"#374151",fontSize:"10px"}}>MODULE: {module?.toUpperCase()}</span>
        <span style={{color:"#374151",fontSize:"10px"}}>KILLBOX v2.4.1 // CLAUDE SONNET</span>
      </div>
    </div>
  );
}

// ─── COMPONENT: VT Panel ──────────────────────────────────────────────────────
function VTPanel({ vtKey, sessionId, logs, addLog }) {
  const [query, setQuery] = useState("");
  const [queryType, setQueryType] = useState("hash");
  const [vtResult, setVtResult] = useState(null);
  const [aiAnalysis, setAiAnalysis] = useState("");
  const [loading, setLoading] = useState(false);
  const [timestamp, setTimestamp] = useState("");

  const vtLookup = async () => {
    if (!vtKey.trim()) { addLog("✗ VirusTotal API key not configured", "error"); return; }
    if (!query.trim()) return;
    setLoading(true); setVtResult(null); setAiAnalysis(""); setTimestamp(formatTs());
    addLog(`▸ VT lookup [${queryType}]: ${query.substring(0,40)}...`, "info");

    const endpoints = {
      hash:   `${VT_API_BASE}/files/${query.trim()}`,
      url:    `${VT_API_BASE}/urls/${btoa(query.trim()).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_")}`,
      domain: `${VT_API_BASE}/domains/${query.trim()}`,
      ip:     `${VT_API_BASE}/ip_addresses/${query.trim()}`,
    };

    try {
      const res = await fetch(endpoints[queryType], {
        headers: { "x-apikey": vtKey }
      });
      const data = await res.json();

      if (data.error) {
        addLog(`✗ VT Error: ${data.error.message}`, "error");
        setLoading(false); return;
      }

      setVtResult(data);
      addLog(`✓ VT data received. Sending to Claude for analysis...`, "success");

      // Claude analysis of VT results
      const vtSummary = JSON.stringify(data.data?.attributes || data, null, 2).substring(0, 6000);
      const claudeRes = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": vtKey.startsWith("sk-ant") ? vtKey : "", "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model: MODEL, max_tokens: MAX_TOKENS, system: SYSTEM_PROMPTS.vt, messages: [{ role:"user", content: `Analyze this VirusTotal API response for ${queryType} "${query}":\n\n${vtSummary}` }] })
      });
      // Note: Claude API key is separate — handled by parent
      addLog("▸ AI analysis pending (set Claude API key in CONFIG)", "warn");

    } catch (e) {
      addLog(`✗ VT request failed: ${e.message}`, "error");
    }
    setLoading(false);
  };

  const attrs = vtResult?.data?.attributes;
  const stats = attrs?.last_analysis_stats;
  const totalEngines = stats ? Object.values(stats).reduce((a,b)=>a+b,0) : 0;

  return (
    <div>
      <div style={{display:"flex",gap:8,marginBottom:12}}>
        {["hash","url","domain","ip"].map(t=>(
          <button key={t} onClick={()=>setQueryType(t)} style={{background:queryType===t?"#1e1b4b":"#0a0f1a",border:`1px solid ${queryType===t?"#7c3aed":"#1e293b"}`,color:queryType===t?"#a78bfa":"#4b5563",padding:"6px 14px",fontSize:"10px",cursor:"pointer",letterSpacing:2}}>
            {t.toUpperCase()}
          </button>
        ))}
      </div>
      <div style={{display:"flex",gap:8,marginBottom:12}}>
        <input value={query} onChange={e=>setQuery(e.target.value)}
          onKeyDown={e=>e.key==="Enter"&&!loading&&vtLookup()}
          placeholder={queryType==="hash"?"SHA256 / MD5 / SHA1 hash...":queryType==="url"?"https://suspicious-url.com":queryType==="domain"?"malicious-domain.com":"1.2.3.4"}
          style={{flex:1,background:"#070b14",border:"1px solid #1e293b",color:"#e2e8f0",padding:"10px 14px",fontSize:"12px",fontFamily:"'Courier New',monospace",outline:"none"}}/>
        <button onClick={vtLookup} disabled={loading||!query.trim()} style={{background:loading?"#1e1b4b":"linear-gradient(135deg,#4c1d95,#7c3aed)",border:"1px solid #7c3aed",color:"#e9d5ff",padding:"10px 20px",fontSize:"10px",cursor:"pointer",letterSpacing:2,opacity:!query.trim()?0.5:1}}>
          {loading?"QUERYING...":"⬛ LOOKUP"}
        </button>
      </div>

      {attrs && (
        <div style={{background:"#070b14",border:"1px solid #1e293b",padding:16,marginTop:8}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:16,flexWrap:"wrap",gap:12}}>
            <div>
              <div style={{color:"#7c3aed",fontSize:10,letterSpacing:3,marginBottom:8}}>VIRUSTOTAL REPORT</div>
              {attrs.meaningful_name&&<div style={{color:"#e879f9",fontSize:13,marginBottom:4}}>{attrs.meaningful_name}</div>}
              {attrs.md5&&<div style={{color:"#64748b",fontSize:11}}>MD5: {attrs.md5}</div>}
              {attrs.sha256&&<div style={{color:"#64748b",fontSize:11}}>SHA256: {attrs.sha256}</div>}
              {attrs.size&&<div style={{color:"#64748b",fontSize:11}}>Size: {(attrs.size/1024).toFixed(1)} KB</div>}
              {attrs.type_description&&<div style={{color:"#64748b",fontSize:11}}>Type: {attrs.type_description}</div>}
            </div>
            {stats&&<div style={{minWidth:200}}>
              <DetectionGauge detected={stats.malicious||0} total={totalEngines} label="Malicious Detections"/>
              <DetectionGauge detected={stats.suspicious||0} total={totalEngines} label="Suspicious Detections"/>
            </div>}
          </div>

          {/* Top engine hits */}
          {attrs.last_analysis_results && (
            <div style={{marginBottom:12}}>
              <div style={{color:"#374151",fontSize:10,letterSpacing:2,marginBottom:6}}>TOP DETECTIONS</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
                {Object.entries(attrs.last_analysis_results)
                  .filter(([,v])=>v.category==="malicious"||v.category==="suspicious")
                  .slice(0,16)
                  .map(([engine,v])=>(
                    <span key={engine} style={{background:"#1e293b",border:"1px solid #374151",color:v.category==="malicious"?"#f87171":"#fbbf24",padding:"2px 8px",fontSize:"10px"}}>
                      {engine}: {v.result||"detected"}
                    </span>
                  ))}
              </div>
            </div>
          )}

          {/* Tags */}
          {attrs.tags?.length>0&&(
            <div style={{display:"flex",flexWrap:"wrap",gap:4,marginBottom:8}}>
              {attrs.tags.map(t=><span key={t} style={{background:"#0a0f1a",border:"1px solid #4c1d95",color:"#a78bfa",padding:"2px 8px",fontSize:"10px"}}>{t}</span>)}
            </div>
          )}

          {/* Sandbox behavior summary */}
          {attrs.sandbox_verdicts&&Object.keys(attrs.sandbox_verdicts).length>0&&(
            <div style={{marginTop:8}}>
              <div style={{color:"#374151",fontSize:10,letterSpacing:2,marginBottom:4}}>SANDBOX VERDICTS</div>
              {Object.entries(attrs.sandbox_verdicts).slice(0,4).map(([sb,v])=>(
                <div key={sb} style={{color:"#64748b",fontSize:11,padding:"3px 0",borderBottom:"1px solid #0f172a"}}>
                  <span style={{color:"#94a3b8"}}>{sb}: </span>
                  <span style={{color:v.category==="malicious"?"#f87171":"#fbbf24"}}>{v.verdict||v.category}</span>
                  {v.malware_names&&<span style={{color:"#e879f9"}}> — {v.malware_names.join(", ")}</span>}
                </div>
              ))}
            </div>
          )}

          <div style={{marginTop:8,color:"#374151",fontSize:10}}>
            First seen: {attrs.first_submission_date?new Date(attrs.first_submission_date*1000).toISOString().slice(0,10):"N/A"} |
            Last seen: {attrs.last_submission_date?new Date(attrs.last_submission_date*1000).toISOString().slice(0,10):"N/A"} |
            Times submitted: {attrs.times_submitted||"N/A"}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── COMPONENT: AbuseIPDB Panel ───────────────────────────────────────────────
function AbusePanel({ abuseKey, addLog }) {
  const [ip, setIp] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [batchIps, setBatchIps] = useState("");
  const [batchResults, setBatchResults] = useState([]);
  const [tab, setTab] = useState("single");

  const CATEGORY_MAP = {
    1:"DNS Compromise",2:"DNS Poisoning",3:"Fraud Orders",4:"DDoS Attack",5:"FTP Brute-Force",
    6:"Ping of Death",7:"Phishing",8:"Fraud VoIP",9:"Open Proxy",10:"Web Spam",11:"Email Spam",
    12:"Blog Spam",13:"VPN IP",14:"Port Scan",15:"Hacking",16:"SQL Injection",17:"Spoofing",
    18:"Brute-Force",19:"Bad Web Bot",20:"Exploited Host",21:"Web App Attack",22:"SSH",23:"IoT Targeted"
  };

  const lookup = async (ipAddr) => {
    if (!abuseKey.trim()) { addLog("✗ AbuseIPDB API key not configured", "error"); return null; }
    const res = await fetch(`${ABUSE_API_BASE}/check?ipAddress=${ipAddr}&maxAgeInDays=90&verbose=true`, {
      headers: { "Key": abuseKey, "Accept": "application/json" }
    });
    const data = await res.json();
    return data.data;
  };

  const handleSingle = async () => {
    if (!ip.trim()) return;
    setLoading(true); setResult(null);
    addLog(`▸ AbuseIPDB check: ${ip}`, "info");
    try {
      const d = await lookup(ip.trim());
      if (d) { setResult(d); addLog(`✓ AbuseIPDB: Score ${d.abuseConfidenceScore}% — ${d.totalReports} reports`, d.abuseConfidenceScore>50?"warn":"success"); }
      else addLog("✗ No data returned", "error");
    } catch(e) { addLog(`✗ AbuseIPDB error: ${e.message}`, "error"); }
    setLoading(false);
  };

  const handleBatch = async () => {
    const ips = batchIps.split(/[\n,\s]+/).map(s=>s.trim()).filter(s=>/^\d{1,3}(\.\d{1,3}){3}$/.test(s));
    if (!ips.length) return;
    setLoading(true); setBatchResults([]);
    addLog(`▸ Batch AbuseIPDB check: ${ips.length} IPs`, "info");
    const results = [];
    for (const addr of ips.slice(0,20)) {
      try { const d = await lookup(addr); if(d) results.push(d); }
      catch(e) { addLog(`  ✗ Failed: ${addr}`, "warn"); }
    }
    setBatchResults(results);
    addLog(`✓ Batch complete: ${results.length}/${ips.length} resolved`, "success");
    setLoading(false);
  };

  const scoreColor = (s) => s>75?"#ef4444":s>50?"#f97316":s>25?"#f59e0b":"#22c55e";

  return (
    <div>
      <div style={{display:"flex",gap:4,marginBottom:12}}>
        {["single","batch"].map(t=>(
          <button key={t} onClick={()=>setTab(t)} style={{background:tab===t?"#1e1b4b":"#0a0f1a",border:`1px solid ${tab===t?"#7c3aed":"#1e293b"}`,color:tab===t?"#a78bfa":"#4b5563",padding:"6px 16px",fontSize:"10px",cursor:"pointer",letterSpacing:2}}>
            {t.toUpperCase()}
          </button>
        ))}
      </div>

      {tab==="single"&&<>
        <div style={{display:"flex",gap:8,marginBottom:12}}>
          <input value={ip} onChange={e=>setIp(e.target.value)} onKeyDown={e=>e.key==="Enter"&&!loading&&handleSingle()}
            placeholder="Enter IP address (e.g. 185.220.101.47)"
            style={{flex:1,background:"#070b14",border:"1px solid #1e293b",color:"#e2e8f0",padding:"10px 14px",fontSize:"12px",fontFamily:"'Courier New',monospace",outline:"none"}}/>
          <button onClick={handleSingle} disabled={loading||!ip.trim()} style={{background:loading?"#1e1b4b":"linear-gradient(135deg,#4c1d95,#7c3aed)",border:"1px solid #7c3aed",color:"#e9d5ff",padding:"10px 20px",fontSize:"10px",cursor:"pointer",letterSpacing:2,opacity:!ip.trim()?0.5:1}}>
            {loading?"CHECKING...":"◍ CHECK"}
          </button>
        </div>

        {result&&(
          <div style={{background:"#070b14",border:"1px solid #1e293b",padding:16}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12,flexWrap:"wrap",gap:12}}>
              <div>
                <div style={{color:"#7c3aed",fontSize:10,letterSpacing:3,marginBottom:4}}>ABUSEIPDB REPORT</div>
                <div style={{color:"#e2e8f0",fontSize:16,fontWeight:"bold",letterSpacing:2}}>{result.ipAddress}</div>
                <div style={{color:"#64748b",fontSize:11,marginTop:2}}>{result.domain||"No rDNS"}</div>
                <div style={{color:"#64748b",fontSize:11}}>{result.countryCode} • {result.isp}</div>
                <div style={{display:"flex",gap:6,marginTop:6,flexWrap:"wrap"}}>
                  {result.isPublic&&<span style={{color:"#94a3b8",fontSize:10,background:"#1e293b",padding:"2px 8px"}}>PUBLIC</span>}
                  {result.isTor&&<span style={{color:"#e879f9",fontSize:10,background:"#2d1b4b",padding:"2px 8px"}}>⬥ TOR EXIT NODE</span>}
                  {result.usageType&&<span style={{color:"#7dd3fc",fontSize:10,background:"#0c1a2e",padding:"2px 8px"}}>{result.usageType}</span>}
                </div>
              </div>
              <div style={{textAlign:"center"}}>
                <div style={{fontSize:36,fontWeight:"900",color:scoreColor(result.abuseConfidenceScore),fontFamily:"'Courier New',monospace",lineHeight:1,textShadow:`0 0 16px ${scoreColor(result.abuseConfidenceScore)}`}}>
                  {result.abuseConfidenceScore}%
                </div>
                <div style={{color:"#374151",fontSize:10,letterSpacing:1,marginTop:2}}>ABUSE CONFIDENCE</div>
                <ThreatBadge level={result.abuseConfidenceScore>75?"CRITICAL":result.abuseConfidenceScore>50?"HIGH":result.abuseConfidenceScore>25?"MEDIUM":"LOW"}/>
              </div>
            </div>

            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
              {[["Total Reports",result.totalReports],["Distinct Users",result.numDistinctUsers],["Last Reported",result.lastReportedAt?result.lastReportedAt.slice(0,10):"Never"],["Country",result.countryName||result.countryCode||"Unknown"]].map(([k,v])=>(
                <div key={k} style={{background:"#0a0f1a",padding:"8px 10px",border:"1px solid #1e293b"}}>
                  <div style={{color:"#374151",fontSize:10}}>{k}</div>
                  <div style={{color:"#94a3b8",fontSize:13,fontWeight:"bold"}}>{v}</div>
                </div>
              ))}
            </div>

            {/* Attack categories */}
            {result.reports?.length>0&&(
              <div>
                <div style={{color:"#374151",fontSize:10,letterSpacing:2,marginBottom:6}}>ATTACK CATEGORIES (from reports)</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
                  {[...new Set(result.reports.flatMap(r=>r.categories||[]))].map(c=>(
                    <span key={c} style={{background:"#0a0f1a",border:"1px solid #374151",color:"#f87171",padding:"2px 8px",fontSize:"10px"}}>{CATEGORY_MAP[c]||`Cat ${c}`}</span>
                  ))}
                </div>
                <div style={{marginTop:8,color:"#374151",fontSize:10,letterSpacing:1}}>RECENT REPORTS</div>
                {result.reports.slice(0,5).map((r,i)=>(
                  <div key={i} style={{borderBottom:"1px solid #0f172a",padding:"4px 0",fontSize:11}}>
                    <span style={{color:"#4b5563"}}>{r.reportedAt?.slice(0,10)} </span>
                    <span style={{color:"#94a3b8"}}>{r.comment?.slice(0,80)||"No comment"}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </>}

      {tab==="batch"&&<>
        <textarea value={batchIps} onChange={e=>setBatchIps(e.target.value)}
          placeholder={"Paste IPs (one per line or comma-separated, max 20):\n185.220.101.47\n1.2.3.4\n5.6.7.8"}
          rows={6}
          style={{width:"100%",background:"#070b14",border:"1px solid #1e293b",color:"#94a3b8",padding:"10px 14px",fontSize:"12px",fontFamily:"'Courier New',monospace",resize:"vertical",outline:"none",boxSizing:"border-box",marginBottom:8}}/>
        <button onClick={handleBatch} disabled={loading||!batchIps.trim()} style={{background:loading?"#1e1b4b":"linear-gradient(135deg,#4c1d95,#7c3aed)",border:"1px solid #7c3aed",color:"#e9d5ff",padding:"10px 20px",fontSize:"10px",cursor:"pointer",letterSpacing:2,width:"100%",opacity:!batchIps.trim()?0.5:1}}>
          {loading?"SCANNING BATCH...":"◍ SCAN ALL IPs"}
        </button>
        {batchResults.length>0&&(
          <div style={{marginTop:12}}>
            <div style={{color:"#374151",fontSize:10,letterSpacing:2,marginBottom:6}}>BATCH RESULTS</div>
            <table style={{width:"100%",borderCollapse:"collapse",fontSize:11,fontFamily:"'Courier New',monospace"}}>
              <thead>
                <tr style={{borderBottom:"1px solid #1e293b"}}>
                  {["IP","Country","ISP","Score","Reports","Tor"].map(h=><th key={h} style={{color:"#374151",textAlign:"left",padding:"4px 8px",fontSize:10}}>{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {batchResults.sort((a,b)=>b.abuseConfidenceScore-a.abuseConfidenceScore).map(r=>(
                  <tr key={r.ipAddress} style={{borderBottom:"1px solid #0f172a"}}>
                    <td style={{color:"#7dd3fc",padding:"4px 8px"}}>{r.ipAddress}</td>
                    <td style={{color:"#64748b",padding:"4px 8px"}}>{r.countryCode||"??"}</td>
                    <td style={{color:"#64748b",padding:"4px 8px",maxWidth:150,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{r.isp||"Unknown"}</td>
                    <td style={{color:scoreColor(r.abuseConfidenceScore),padding:"4px 8px",fontWeight:"bold"}}>{r.abuseConfidenceScore}%</td>
                    <td style={{color:"#94a3b8",padding:"4px 8px"}}>{r.totalReports}</td>
                    <td style={{color:r.isTor?"#e879f9":"#374151",padding:"4px 8px"}}>{r.isTor?"YES":"—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </>}
    </div>
  );
}

// ─── COMPONENT: Heuristic Panel ───────────────────────────────────────────────
function HeuristicPanel({ apiKey, addLog, sessionId }) {
  const [input, setInput] = useState("");
  const [scanResult, setScanResult] = useState(null);
  const [aiAnalysis, setAiAnalysis] = useState("");
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [timestamp, setTimestamp] = useState("");
  const [filterSeverity, setFilterSeverity] = useState("ALL");

  const runScan = () => {
    if (!input.trim()) return;
    setTimestamp(formatTs());
    addLog("▸ Running heuristic engine...", "info");
    const result = runHeuristicEngine(input);
    setScanResult(result);
    setAiAnalysis("");
    addLog(`✓ Heuristic scan complete: ${result.hits.length} hits, score ${result.score}/100, verdict: ${result.verdict}`, result.verdict==="MALICIOUS"?"error":result.verdict==="SUSPICIOUS"?"warn":"success");
  };

  const runAiAnalysis = async () => {
    if (!apiKey.trim()) { addLog("✗ Claude API key required for AI analysis", "error"); return; }
    if (!scanResult) return;
    setAiLoading(true);
    addLog("▸ Sending heuristic results to Claude for deep analysis...", "accent");

    const hitsReport = scanResult.hits.map(h=>
      `[${h.id}] ${h.name} (${h.severity}) — Family: ${h.family}, MITRE: ${h.tactic}\n  ${h.desc}`
    ).join("\n");

    const prompt = `KILLBOX Heuristic Engine Results:
Score: ${scanResult.score}/100 | Verdict: ${scanResult.verdict}
Hits: ${scanResult.hits.length} signatures matched
Families: ${JSON.stringify(scanResult.families)}

Signature Matches:
${hitsReport}

Raw Input Sample (first 3000 chars):
${input.substring(0,3000)}

Provide deep analysis of these heuristic findings.`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST",
        headers:{"Content-Type":"application/json","x-api-key":apiKey,"anthropic-version":"2023-06-01"},
        body:JSON.stringify({model:MODEL,max_tokens:MAX_TOKENS,system:SYSTEM_PROMPTS.heuristic,messages:[{role:"user",content:prompt}]})
      });
      const data = await res.json();
      if(!data.error) {
        setAiAnalysis(data.content.map(b=>b.text||"").join("\n"));
        addLog("✓ AI heuristic analysis complete","success");
      } else addLog(`✗ Claude error: ${data.error.message}`,"error");
    } catch(e) { addLog(`✗ ${e.message}`,"error"); }
    setAiLoading(false);
  };

  const filteredHits = scanResult?.hits.filter(h=> filterSeverity==="ALL" || h.severity===filterSeverity) || [];

  return (
    <div>
      <div style={{background:"#0a0f1a",border:"1px solid #1e293b",padding:"10px 14px",marginBottom:10}}>
        <div style={{color:"#374151",fontSize:10,letterSpacing:2,marginBottom:4}}>ENGINE INFO</div>
        <div style={{color:"#64748b",fontSize:11}}>
          {SIGNATURES.length} signatures loaded • Families: Ransomware, RAT, Stealer, Persistence, Evasion, C2, Obfuscation, Phishing, Exfiltration
        </div>
      </div>

      <textarea value={input} onChange={e=>setInput(e.target.value)}
        placeholder={"Paste any suspicious content for heuristic analysis:\n• Script code (PowerShell, VBS, Python, Bash)\n• Email body or headers\n• Process command lines\n• Log entries\n• Configuration files\n• String dumps from binaries\n• Network traffic descriptions"}
        rows={7}
        style={{width:"100%",background:"#070b14",border:"1px solid #1e293b",borderLeft:"2px solid #374151",color:"#94a3b8",padding:"12px 14px",fontSize:"12px",fontFamily:"'Courier New',monospace",resize:"vertical",outline:"none",boxSizing:"border-box"}}
        onFocus={e=>e.target.style.borderLeftColor="#7c3aed"}
        onBlur={e=>e.target.style.borderLeftColor="#374151"}/>

      <div style={{display:"flex",gap:8,marginTop:8,marginBottom:12}}>
        <button onClick={runScan} disabled={!input.trim()} style={{flex:1,background:"linear-gradient(135deg,#4c1d95,#7c3aed)",border:"1px solid #7c3aed",color:"#e9d5ff",padding:"10px 0",fontSize:"11px",cursor:"pointer",letterSpacing:3,opacity:!input.trim()?0.5:1}}>
          ◬ RUN HEURISTIC SCAN
        </button>
        {scanResult&&<button onClick={runAiAnalysis} disabled={aiLoading||!apiKey} style={{flex:1,background:"#0a0f1a",border:"1px solid #4c1d95",color:aiLoading?"#4c1d95":"#a78bfa",padding:"10px 0",fontSize:"11px",cursor:"pointer",letterSpacing:2}}>
          {aiLoading?"◈ AI ANALYZING...":"◈ DEEP AI ANALYSIS"}
        </button>}
        {scanResult&&<button onClick={()=>{setScanResult(null);setAiAnalysis("");setInput("");}} style={{background:"#0a0f1a",border:"1px solid #1e293b",color:"#374151",padding:"10px 16px",fontSize:"10px",cursor:"pointer"}}>CLEAR</button>}
      </div>

      {scanResult&&(
        <div>
          {/* Score + verdict */}
          <div style={{background:"#070b14",border:"1px solid #1e293b",padding:16,marginBottom:10}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:12}}>
              <div>
                <div style={{color:"#7c3aed",fontSize:10,letterSpacing:3,marginBottom:8}}>HEURISTIC SCAN RESULTS</div>
                <div style={{color:"#94a3b8",fontSize:13,marginBottom:4}}>{scanResult.hits.length} signatures matched from {SIGNATURES.length} total</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:4,marginTop:8}}>
                  {Object.entries(scanResult.families).map(([fam,cnt])=>(
                    <span key={fam} style={{background:"#0f172a",border:"1px solid #374151",color:"#94a3b8",padding:"2px 10px",fontSize:"10px"}}>
                      {fam}: {cnt}
                    </span>
                  ))}
                  {Object.keys(scanResult.families).length===0&&<span style={{color:"#374151",fontSize:11}}>No matching families</span>}
                </div>
                <div style={{marginTop:8,color:"#374151",fontSize:10}}>{timestamp}</div>
              </div>
              <ScoreRing score={scanResult.score} verdict={scanResult.verdict}/>
            </div>
          </div>

          {/* Filter */}
          {scanResult.hits.length>0&&(
            <>
              <div style={{display:"flex",gap:4,marginBottom:8,alignItems:"center"}}>
                <span style={{color:"#374151",fontSize:10,marginRight:4}}>FILTER:</span>
                {["ALL","CRITICAL","HIGH","MEDIUM","LOW"].map(s=>(
                  <button key={s} onClick={()=>setFilterSeverity(s)} style={{background:filterSeverity===s?"#1e1b4b":"#0a0f1a",border:`1px solid ${filterSeverity===s?"#7c3aed":"#1e293b"}`,color:filterSeverity===s?"#a78bfa":"#4b5563",padding:"3px 10px",fontSize:"10px",cursor:"pointer"}}>
                    {s}
                  </button>
                ))}
              </div>
              <div style={{maxHeight:320,overflowY:"auto"}}>
                {filteredHits.map(h=><HeuristicHitCard key={h.id} hit={h}/>)}
              </div>
            </>
          )}

          {/* AI Analysis */}
          {aiAnalysis&&(
            <div style={{background:"#070b14",border:"1px solid #1e293b",borderTop:"2px solid #e879f9",padding:16,marginTop:10}}>
              <div style={{color:"#e879f9",fontSize:10,letterSpacing:3,marginBottom:10}}>◈ AI DEEP ANALYSIS</div>
              <div style={{color:"#cbd5e1",fontSize:13,lineHeight:1.8,whiteSpace:"pre-wrap",maxHeight:500,overflowY:"auto"}}
                dangerouslySetInnerHTML={{__html:aiAnalysis
                  .replace(/\*\*(.*?)\*\*/g,'<strong style="color:#e879f9">$1</strong>')
                  .replace(/`([^`]+)`/g,'<code style="background:#1e293b;color:#7dd3fc;padding:1px 5px;font-size:12px">$1</code>')
                  .replace(/^#{1,3}\s(.+)$/gm,'<div style="color:#7c3aed;font-weight:bold;margin:8px 0 3px">◈ $1</div>')
                  .replace(/T\d{4}(\.\d{3})?/g,'<span style="color:#f59e0b;font-weight:bold">$&</span>')
                }}/>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function Killbox() {
  const [activeModule, setActiveModule] = useState("static");
  const [input, setInput] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [vtKey, setVtKey] = useState("");
  const [abuseKey, setAbuseKey] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [sessionId] = useState(genSession);
  const [timestamp, setTimestamp] = useState("");
  const [logs, setLogs] = useState([]);
  const [showConfig, setShowConfig] = useState(false);
  const [convHistory, setConvHistory] = useState([]);
  const [followUp, setFollowUp] = useState("");
  const logRef = useRef(null);

  useEffect(() => {
    const boot = [
      {text:"KILLBOX THREAT ANALYSIS FRAMEWORK v2.4.1",type:"accent",delay:100},
      {text:"Initializing modules...",type:"dim",delay:400},
      {text:"▸ Static/Email/Behavioral/Network/YARA/Threat..[READY]",type:"success",delay:700},
      {text:"▸ VirusTotal integration...................[STANDBY]",type:"warn",delay:900},
      {text:"▸ AbuseIPDB integration....................[STANDBY]",type:"warn",delay:1100},
      {text:`▸ Heuristic engine (${SIGNATURES.length} sigs).............[READY]`,type:"success",delay:1300},
      {text:"▸ Claude AI backend........................[STANDBY]",type:"warn",delay:1500},
      {text:`Session: ${sessionId} // Platform: Debian GNU/Linux 12`,type:"data",delay:1700},
      {text:"⬢ READY. Configure API keys to begin.",type:"info",delay:1900},
    ];
    setLogs(boot);
  }, []);

  useEffect(() => { if(logRef.current) logRef.current.scrollTop=logRef.current.scrollHeight; }, [logs]);

  const addLog = useCallback((text, type="info") => {
    setLogs(prev=>[...prev,{text,type,delay:0}]);
  },[]);

  const handleAnalyze = useCallback(async () => {
    if(!input.trim()||!apiKey.trim()) { if(!apiKey.trim()){addLog("✗ Claude API key required","error");setShowConfig(true);} return; }
    setLoading(true); setResult(null); setTimestamp(formatTs()); setConvHistory([]);
    addLog(`▸ Running ${MODULES.find(m=>m.id===activeModule)?.label}...`,"info");
    try {
      const userMsg = {role:"user",content:input};
      const res = await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",
        headers:{"Content-Type":"application/json","x-api-key":apiKey,"anthropic-version":"2023-06-01"},
        body:JSON.stringify({model:MODEL,max_tokens:MAX_TOKENS,system:SYSTEM_PROMPTS[activeModule],messages:[userMsg]})
      });
      const data = await res.json();
      if(data.error){addLog(`✗ ${data.error.message}`,"error");setLoading(false);return;}
      const text = data.content.map(b=>b.text||"").join("\n");
      setResult(text);
      setConvHistory([userMsg,{role:"assistant",content:text}]);
      addLog(`✓ Analysis complete. Tokens: ${(data.usage?.input_tokens||0)+(data.usage?.output_tokens||0)}`,"success");
    } catch(e){addLog(`✗ ${e.message}`,"error");}
    setLoading(false);
  },[input,apiKey,activeModule]);

  const handleFollowUp = useCallback(async () => {
    if(!followUp.trim()||!convHistory.length||!apiKey.trim()) return;
    setLoading(true);
    addLog("▸ Follow-up query...","info");
    try {
      const newHist=[...convHistory,{role:"user",content:followUp}];
      const res = await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",
        headers:{"Content-Type":"application/json","x-api-key":apiKey,"anthropic-version":"2023-06-01"},
        body:JSON.stringify({model:MODEL,max_tokens:MAX_TOKENS,system:SYSTEM_PROMPTS[activeModule],messages:newHist})
      });
      const data = await res.json();
      if(!data.error){
        const text=data.content.map(b=>b.text||"").join("\n");
        setResult(prev=>prev+"\n\n─────────────────────────────\n**FOLLOW-UP**\n─────────────────────────────\n\n"+text);
        setConvHistory([...newHist,{role:"assistant",content:text}]);
        addLog("✓ Follow-up complete","success");
      }
    } catch(e){addLog(`✗ ${e.message}`,"error");}
    setFollowUp(""); setLoading(false);
  },[followUp,convHistory,apiKey,activeModule]);

  const coreModules = MODULES.filter(m=>!["vt","abuse","heuristic"].includes(m.id));
  const enrichModules = MODULES.filter(m=>["vt","abuse","heuristic"].includes(m.id));

  return (
    <div style={{background:"#030712",minHeight:"100vh",color:"#e2e8f0",fontFamily:"'Courier New',monospace",padding:0,margin:0}}>
      {/* Grid bg */}
      <div style={{position:"fixed",inset:0,backgroundImage:"linear-gradient(rgba(124,58,237,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(124,58,237,0.03) 1px,transparent 1px)",backgroundSize:"40px 40px",pointerEvents:"none"}}/>

      <div style={{maxWidth:1200,margin:"0 auto",padding:20}}>
        {/* ── HEADER ── */}
        <div style={{borderBottom:"1px solid #1e293b",paddingBottom:16,marginBottom:16}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:12}}>
            <div>
              <div style={{display:"flex",alignItems:"baseline",gap:16}}>
                <h1 style={{margin:0,fontSize:30,fontWeight:900,letterSpacing:8,background:"linear-gradient(135deg,#7c3aed,#e879f9,#7c3aed)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",backgroundSize:"200%",animation:"gradientShift 4s ease infinite"}}>KILLBOX</h1>
                <span style={{color:"#374151",fontSize:10,letterSpacing:3}}>THREAT ANALYSIS ENGINE</span>
              </div>
              <div style={{display:"flex",gap:12,marginTop:4,flexWrap:"wrap"}}>
                <span style={{color:"#4b5563",fontSize:10}}>v2.4.1</span>
                <span style={{color:"#4b5563",fontSize:10}}>◈ Debian/Fedora</span>
                <span style={{color:apiKey?"#22c55e":"#4b5563",fontSize:10}}>◈ Claude {apiKey?"●":"○"}</span>
                <span style={{color:vtKey?"#22c55e":"#4b5563",fontSize:10}}>◈ VirusTotal {vtKey?"●":"○"}</span>
                <span style={{color:abuseKey?"#22c55e":"#4b5563",fontSize:10}}>◈ AbuseIPDB {abuseKey?"●":"○"}</span>
                <span style={{color:"#22c55e",fontSize:10}}>◈ Heuristic ●</span>
              </div>
            </div>
            <div style={{display:"flex",gap:8,alignItems:"center"}}>
              <div style={{textAlign:"right"}}>
                <div style={{color:"#4b5563",fontSize:10}}>SESSION</div>
                <div style={{color:"#7c3aed",fontSize:12,letterSpacing:2}}>{sessionId}</div>
              </div>
              <button onClick={()=>setShowConfig(!showConfig)} style={{background:showConfig?"#1e1b4b":"#0f172a",border:`1px solid ${showConfig?"#7c3aed":"#374151"}`,color:showConfig?"#a78bfa":"#64748b",padding:"8px 16px",fontSize:"10px",cursor:"pointer",letterSpacing:2}}>
                ⬡ CONFIG
              </button>
            </div>
          </div>
        </div>

        {/* ── CONFIG PANEL ── */}
        {showConfig&&(
          <div style={{background:"#0a0f1a",border:"1px solid #7c3aed",padding:16,marginBottom:16,animation:"fadeIn 0.2s ease"}}>
            <div style={{color:"#e879f9",fontSize:11,letterSpacing:3,marginBottom:12}}>◈ API KEY CONFIGURATION</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12}}>
              {[
                {label:"Anthropic Claude API",placeholder:"sk-ant-api03-...",value:apiKey,set:setApiKey,note:"console.anthropic.com"},
                {label:"VirusTotal API Key",placeholder:"64-char hex key...",value:vtKey,set:setVtKey,note:"virustotal.com/gui/my-apikey"},
                {label:"AbuseIPDB API Key",placeholder:"AbuseIPDB v2 key...",value:abuseKey,set:setAbuseKey,note:"abuseipdb.com/account/api"},
              ].map(({label,placeholder,value,set,note})=>(
                <div key={label}>
                  <div style={{color:"#64748b",fontSize:10,marginBottom:4}}>{label}</div>
                  <input type="password" value={value} onChange={e=>set(e.target.value)} placeholder={placeholder}
                    style={{width:"100%",background:"#030712",border:"1px solid #374151",color:"#e2e8f0",padding:"8px 10px",fontSize:"11px",fontFamily:"'Courier New',monospace",outline:"none",boxSizing:"border-box"}}/>
                  <div style={{color:"#1e293b",fontSize:9,marginTop:2}}>{note}</div>
                </div>
              ))}
            </div>
            <button onClick={()=>{setShowConfig(false);addLog("✓ API keys saved to session memory","success");}} style={{background:"#1e1b4b",border:"1px solid #7c3aed",color:"#a78bfa",padding:"8px 24px",fontSize:"10px",cursor:"pointer",letterSpacing:2,marginTop:12}}>
              ✓ APPLY & CLOSE
            </button>
          </div>
        )}

        <div style={{display:"grid",gridTemplateColumns:"210px 1fr",gap:14}}>
          {/* ── SIDEBAR ── */}
          <div>
            <div style={{background:"#070b14",border:"1px solid #1e293b",padding:4,marginBottom:12}}>
              <div style={{color:"#374151",fontSize:9,letterSpacing:2,padding:"6px 10px 3px"}}>CORE MODULES</div>
              {coreModules.map(mod=>(
                <button key={mod.id} onClick={()=>{setActiveModule(mod.id);setResult(null);setConvHistory([]);}}
                  style={{display:"flex",alignItems:"center",gap:8,width:"100%",background:activeModule===mod.id?"#1e1b4b":"transparent",border:"none",borderLeft:activeModule===mod.id?"2px solid #7c3aed":"2px solid transparent",color:activeModule===mod.id?"#a78bfa":"#64748b",padding:"8px 10px",fontSize:"11px",cursor:"pointer",textAlign:"left",letterSpacing:1,transition:"all 0.15s"}}>
                  <span>{mod.icon}</span>{mod.label}
                </button>
              ))}
              <div style={{color:"#374151",fontSize:9,letterSpacing:2,padding:"10px 10px 3px",borderTop:"1px solid #0f172a",marginTop:4}}>ENRICHMENT</div>
              {enrichModules.map(mod=>(
                <button key={mod.id} onClick={()=>{setActiveModule(mod.id);setResult(null);setConvHistory([]);}}
                  style={{display:"flex",alignItems:"center",gap:8,width:"100%",background:activeModule===mod.id?"#1e1b4b":"transparent",border:"none",borderLeft:activeModule===mod.id?"2px solid #e879f9":"2px solid transparent",color:activeModule===mod.id?"#f0abfc":"#64748b",padding:"8px 10px",fontSize:"11px",cursor:"pointer",textAlign:"left",letterSpacing:1,transition:"all 0.15s"}}>
                  <span>{mod.icon}</span>{mod.label}
                  {mod.id==="heuristic"&&<span style={{marginLeft:"auto",color:"#22c55e",fontSize:9}}>●</span>}
                </button>
              ))}
            </div>

            {/* System log */}
            <div style={{background:"#070b14",border:"1px solid #1e293b",padding:10}}>
              <div style={{color:"#374151",fontSize:9,letterSpacing:2,marginBottom:6}}>SYSTEM LOG</div>
              <div ref={logRef} style={{maxHeight:260,overflowY:"auto"}}>
                {logs.map((l,i)=><TerminalLine key={i} type={l.type} delay={l.delay}><span style={{color:"#1f2937"}}>[{String(i).padStart(3,"0")}] </span>{l.text}</TerminalLine>)}
                {loading&&<TerminalLine type="accent"><span style={{animation:"blink 1s infinite"}}>▋</span> Processing...</TerminalLine>}
              </div>
            </div>

            {/* Sig stats */}
            <div style={{background:"#070b14",border:"1px solid #1e293b",padding:10,marginTop:12}}>
              <div style={{color:"#374151",fontSize:9,letterSpacing:2,marginBottom:6}}>SIGNATURE STATS</div>
              {[
                ["Total Sigs",SIGNATURES.length],
                ["Critical",SIGNATURES.filter(s=>s.severity==="CRITICAL").length],
                ["High",SIGNATURES.filter(s=>s.severity==="HIGH").length],
                ["Medium",SIGNATURES.filter(s=>s.severity==="MEDIUM").length],
              ].map(([k,v])=>(
                <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"3px 0",borderBottom:"1px solid #0f172a"}}>
                  <span style={{color:"#4b5563",fontSize:10}}>{k}</span>
                  <span style={{color:"#22c55e",fontSize:10}}>{v}</span>
                </div>
              ))}
            </div>
          </div>

          {/* ── MAIN PANEL ── */}
          <div>
            <div style={{background:"#070b14",border:"1px solid #1e293b",borderTop:`2px solid ${["vt","abuse","heuristic"].includes(activeModule)?"#e879f9":"#7c3aed"}`,padding:"10px 14px",marginBottom:10}}>
              <span style={{color:["vt","abuse","heuristic"].includes(activeModule)?"#e879f9":"#7c3aed",fontSize:"10px",letterSpacing:3}}>
                {MODULES.find(m=>m.id===activeModule)?.icon} KILLBOX/{activeModule.toUpperCase()}
              </span>
              <span style={{color:"#374151",fontSize:10,marginLeft:12}}>{MODULES.find(m=>m.id===activeModule)?.label}</span>
            </div>

            {/* Enrichment modules render their own UI */}
            {activeModule==="vt"&&<VTPanel vtKey={vtKey} sessionId={sessionId} logs={logs} addLog={addLog}/>}
            {activeModule==="abuse"&&<AbusePanel abuseKey={abuseKey} addLog={addLog}/>}
            {activeModule==="heuristic"&&<HeuristicPanel apiKey={apiKey} addLog={addLog} sessionId={sessionId}/>}

            {/* Core modules */}
            {!["vt","abuse","heuristic"].includes(activeModule)&&<>
              <div style={{position:"relative"}}>
                <textarea value={input} onChange={e=>setInput(e.target.value)}
                  placeholder={{"static":"Paste hashes, hex dumps, strings, base64, suspicious code...","email":"Paste raw email headers, .eml content, phishing URLs, attachment hashes...","behavioral":"Paste API call sequences, process trees, registry changes, behavior logs...","network":"Paste IPs, domains, URLs, DNS queries, PCAP snippets...","yara":"Paste malware strings, hex patterns, IOCs to generate YARA rules...","threat":"Paste TTPs, hashes, infrastructure, campaign data for attribution..."}[activeModule]}
                  rows={8}
                  style={{width:"100%",background:"#070b14",border:"1px solid #1e293b",borderLeft:"2px solid #374151",color:"#94a3b8",padding:"12px 14px",fontSize:"12px",fontFamily:"'Courier New',monospace",resize:"vertical",outline:"none",boxSizing:"border-box",lineHeight:1.6}}
                  onFocus={e=>e.target.style.borderLeftColor="#7c3aed"}
                  onBlur={e=>e.target.style.borderLeftColor="#374151"}/>
              </div>
              <div style={{display:"flex",gap:8,marginTop:8}}>
                <button onClick={handleAnalyze} disabled={loading||!input.trim()}
                  style={{flex:1,background:loading?"#1e1b4b":"linear-gradient(135deg,#4c1d95,#7c3aed)",border:"1px solid #7c3aed",color:loading?"#6d28d9":"#e9d5ff",padding:"11px 0",fontSize:"11px",fontFamily:"'Courier New',monospace",cursor:loading||!input.trim()?"not-allowed":"pointer",letterSpacing:3,fontWeight:"bold",opacity:!input.trim()?0.5:1}}>
                  {loading?"◈ ANALYZING...":"⬢ EXECUTE ANALYSIS"}
                </button>
                <button onClick={()=>{setInput("");setResult(null);setConvHistory([]);}} style={{background:"#0a0f1a",border:"1px solid #1e293b",color:"#374151",padding:"11px 16px",fontSize:"10px",cursor:"pointer",letterSpacing:2}}>
                  CLEAR
                </button>
              </div>
              {result&&<>
                <ResultPanel result={result} module={activeModule} sessionId={sessionId} timestamp={timestamp}/>
                <div style={{display:"flex",gap:8,marginTop:10}}>
                  <input value={followUp} onChange={e=>setFollowUp(e.target.value)} onKeyDown={e=>e.key==="Enter"&&!loading&&handleFollowUp()}
                    placeholder="Follow-up question (e.g. 'Generate Sigma rules' or 'Expand on the C2 infrastructure')..."
                    style={{flex:1,background:"#070b14",border:"1px solid #1e293b",color:"#94a3b8",padding:"10px 12px",fontSize:"12px",fontFamily:"'Courier New',monospace",outline:"none"}}
                    onFocus={e=>e.target.style.borderColor="#7c3aed"} onBlur={e=>e.target.style.borderColor="#1e293b"}/>
                  <button onClick={handleFollowUp} disabled={loading||!followUp.trim()} style={{background:"#0a0f1a",border:"1px solid #4c1d95",color:"#7c3aed",padding:"10px 14px",fontSize:"10px",cursor:"pointer",letterSpacing:2,opacity:!followUp.trim()?0.5:1}}>
                    ◈ QUERY
                  </button>
                </div>
              </>}
            </>}
          </div>
        </div>

        <div style={{borderTop:"1px solid #0f172a",marginTop:20,paddingTop:10,display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:8}}>
          <span style={{color:"#1e293b",fontSize:10}}>VirusTotal · AbuseIPDB · {SIGNATURES.length}-sig Heuristic Engine · MITRE ATT&CK · Claude AI</span>
          <span style={{color:"#1e293b",fontSize:10}}>KILLBOX © 2025 // FOR AUTHORIZED SECURITY RESEARCH ONLY</span>
        </div>
      </div>

      <style>{`
        @keyframes gradientShift{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}
        @keyframes fadeIn{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:0}}
        *{scrollbar-width:thin;scrollbar-color:#1e293b #030712}
        *::-webkit-scrollbar{width:4px;height:4px}
        *::-webkit-scrollbar-track{background:#030712}
        *::-webkit-scrollbar-thumb{background:#1e293b}
        textarea::placeholder,input::placeholder{color:#1f2937!important}
      `}</style>
    </div>
  );
}
