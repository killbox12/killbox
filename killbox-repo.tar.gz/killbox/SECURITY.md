# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 2.4.x   | ✅ Active  |
| < 2.4   | ❌ EOL     |

## Reporting Vulnerabilities

If you discover a security vulnerability in KILLBOX itself, please report it
responsibly by opening a **private security advisory** on GitHub rather than
a public issue:

1. Go to the repo → **Security** tab → **Report a vulnerability**
2. Include: description, reproduction steps, impact assessment
3. We will respond within 72 hours

## ⚠ Usage Warning

KILLBOX is a security research tool. Misuse against systems without explicit
authorization is illegal. By using this software you agree to:

- Only analyze systems you own or have written permission to test
- Comply with all applicable local, national, and international laws
- Not use this tool for offensive or criminal purposes

## API Key Security

- API keys are stored in `/opt/killbox/config.json` (chmod 600, root only)
- Keys are **never** logged, committed, or transmitted outside official APIs
- The web UI stores keys in session memory only (never persisted to disk)
- Rotate keys immediately if you suspect compromise
