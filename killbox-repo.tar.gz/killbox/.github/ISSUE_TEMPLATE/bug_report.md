---
name: Bug Report
about: Report a bug in KILLBOX
labels: bug
---

**Module affected:**
(Static / Email / VirusTotal / AbuseIPDB / Heuristic / CLI / Docker)

**Describe the bug:**

**To reproduce:**
1.
2.

**Expected vs actual behavior:**

**Environment:**
- OS: (e.g. Debian 12 / Ubuntu 22.04 / Docker)
- KILLBOX version: 2.4.x
- Install method: bare metal / Docker

**Logs (sanitize API keys and IOCs before pasting):**
