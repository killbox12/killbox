---
name: New Heuristic Signature
about: Request or contribute a new detection signature
labels: enhancement, signatures
---

**Malware family / technique:**

**MITRE ATT&CK ID:** T1XXX

**Proposed pattern (regex):**
```
your_pattern_here
```

**Severity:** CRITICAL / HIGH / MEDIUM / LOW

**Sample indicators (sanitized — no live malware hashes or working C2 URLs):**

**Why this detection matters:**
