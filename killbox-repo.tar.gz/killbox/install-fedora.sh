#!/usr/bin/env bash
# ============================================================
#  KILLBOX — Fedora / RHEL / Rocky / AlmaLinux Installer
#  Tested: Fedora 39+, RHEL 9, Rocky Linux 9, AlmaLinux 9
# ============================================================

set -euo pipefail
RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'
YELLOW='\033[1;33m'; PURPLE='\033[0;35m'; NC='\033[0m'; BOLD='\033[1m'

KB_DIR="/opt/killbox"
LOG_FILE="/var/log/killbox-install.log"

log()   { echo -e "${GREEN}[+]${NC} $*" | tee -a "$LOG_FILE"; }
warn()  { echo -e "${YELLOW}[!]${NC} $*" | tee -a "$LOG_FILE"; }
error() { echo -e "${RED}[✗]${NC} $*" | tee -a "$LOG_FILE"; exit 1; }

[[ $EUID -ne 0 ]] && error "Run as root: sudo bash install-fedora.sh"

echo -e "${PURPLE}${BOLD}KILLBOX Fedora/RHEL Installer${NC}"
mkdir -p "$KB_DIR" "$(dirname $LOG_FILE)" && touch "$LOG_FILE"

# Detect package manager
if command -v dnf &>/dev/null; then PKG="dnf"; else PKG="yum"; fi
log "Package manager: $PKG"

# Enable EPEL (RHEL/Rocky/Alma)
if [[ -f /etc/redhat-release ]] && ! grep -qi fedora /etc/redhat-release; then
  $PKG install -y epel-release 2>&1 | tee -a "$LOG_FILE"
  $PKG install -y --enablerepo=crb \
    https://dl.fedoraproject.org/pub/epel/epel-release-latest-9.noarch.rpm 2>/dev/null || true
fi

log "Installing system packages..."
$PKG install -y \
  curl wget git unzip tar gzip bzip2 ca-certificates \
  gcc gcc-c++ make cmake pkgconfig \
  openssl-devel libffi-devel zlib-devel bzip2-devel \
  pcre-devel jansson-devel file-libs file-devel \
  python3 python3-pip python3-devel python3-virtualenv \
  binutils nasm file xxd \
  p7zip p7zip-plugins cabextract \
  tcpdump wireshark-cli \
  nmap nc bind-utils whois \
  sqlite jq openssl \
  strace ltrace \
  perl-Image-ExifTool \
  clamav clamd clamav-update \
  2>&1 | tee -a "$LOG_FILE"

# Node.js 20 via NodeSource
log "Installing Node.js 20..."
curl -fsSL https://rpm.nodesource.com/setup_20.x | bash - 2>&1 | tee -a "$LOG_FILE"
$PKG install -y nodejs 2>&1 | tee -a "$LOG_FILE"

# YARA
log "Installing YARA..."
$PKG install -y yara 2>&1 | tee -a "$LOG_FILE" || {
  warn "Building YARA from source..."
  cd /tmp
  wget -q https://github.com/VirusTotal/yara/releases/download/v4.5.1/yara-4.5.1.tar.gz
  tar xf yara-4.5.1.tar.gz && cd yara-4.5.1
  ./bootstrap.sh && ./configure --with-crypto --enable-magic
  make -j"$(nproc)" && make install && ldconfig
}

# Python tools in venv
log "Setting up Python virtualenv..."
python3 -m venv "$KB_DIR/venv"
source "$KB_DIR/venv/bin/activate"
pip install --quiet --upgrade pip
pip install --quiet \
  pefile yara-python python-magic oletools capstone \
  dnspython requests beautifulsoup4 cryptography \
  email-validator mailparser checkdmarc \
  extract-msg msoffcrypto-tool stix2 volatility3 \
  binwalk scapy
deactivate
log "Python tools installed"

# Web app
log "Setting up web interface..."
mkdir -p "$KB_DIR/app/src"
if [[ -f ./killbox.jsx ]]; then
  cp killbox.jsx "$KB_DIR/app/src/App.jsx"
fi
# [package.json and vite.config.js same as in install.sh — copy from Debian version]

# Systemd service
cat > /etc/systemd/system/killbox.service << SERVICE
[Unit]
Description=KILLBOX Threat Analysis Framework
After=network.target

[Service]
Type=simple
WorkingDirectory=${KB_DIR}/app
ExecStart=/usr/bin/npm run dev
Restart=always
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable --now killbox.service

# ClamAV
freshclam 2>/dev/null || warn "Run freshclam manually to update AV database"

# YARA rules
git clone --depth=1 https://github.com/Neo23x0/signature-base.git \
  "$KB_DIR/rules/signature-base" 2>/dev/null || warn "Clone YARA rules manually"

# SELinux: allow web ports
command -v semanage &>/dev/null && \
  semanage port -a -t http_port_t -p tcp 8080 2>/dev/null || true
command -v firewall-cmd &>/dev/null && \
  firewall-cmd --permanent --add-port=8080/tcp && \
  firewall-cmd --reload || true

IP=$(hostname -I | awk '{print $1}')
echo ""
echo -e "${GREEN}${BOLD}KILLBOX installed successfully!${NC}"
echo -e "  Web UI: ${CYAN}http://${IP}:8080${NC}"
echo -e "  CLI:    ${CYAN}kb-scan -h${NC}"
