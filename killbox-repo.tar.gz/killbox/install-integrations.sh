#!/usr/bin/env bash
# ============================================================
#  KILLBOX — Integration Patch Installer
#  Adds: VirusTotal v3, AbuseIPDB v2, Heuristic Engine
#  Run after base install.sh: sudo bash install-integrations.sh
# ============================================================
set -euo pipefail
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; PURPLE='\033[0;35m'; NC='\033[0m'; BOLD='\033[1m'

KB_DIR="/opt/killbox"
log()  { echo -e "${GREEN}[+]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }

echo -e "${PURPLE}${BOLD}"
echo "  ╔══════════════════════════════════════╗"
echo "  ║  KILLBOX Integration Patch v2.4.1   ║"
echo "  ║  VirusTotal + AbuseIPDB + Heuristic  ║"
echo "  ╚══════════════════════════════════════╝"
echo -e "${NC}"

[[ $EUID -ne 0 ]] && echo "Run as root" && exit 1

# ── Python deps for enrichment module ─────────────────────────────────────────
log "Installing Python enrichment dependencies..."
source "$KB_DIR/venv/bin/activate"
pip install --quiet requests aiohttp httpx 2>&1
deactivate

# ── Install kb_enrich.py ──────────────────────────────────────────────────────
log "Deploying kb-enrich CLI tool..."
cp scripts/kb_enrich.py "$KB_DIR/bin/kb_enrich.py"
chmod +x "$KB_DIR/bin/kb_enrich.py"

cat > /usr/local/bin/kb-enrich << 'WRAPPER'
#!/usr/bin/env bash
source /opt/killbox/venv/bin/activate
exec python3 /opt/killbox/bin/kb_enrich.py "$@"
WRAPPER
chmod +x /usr/local/bin/kb-enrich

# ── Update web UI ──────────────────────────────────────────────────────────────
log "Updating web application..."
if [[ -f "killbox_v2.jsx" ]]; then
  cp killbox_v2.jsx "$KB_DIR/app/src/App.jsx"
  log "Web UI updated with VT/AbuseIPDB/Heuristic panels"
else
  warn "killbox_v2.jsx not found — update manually"
fi

# ── Configure API keys ────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}Configure API Keys${NC} (press Enter to skip)"
CONFIG_FILE="$KB_DIR/config.json"
[[ -f "$CONFIG_FILE" ]] || echo "{}" > "$CONFIG_FILE"

read -rp "  VirusTotal API Key (virustotal.com/gui/my-apikey): " VT_KEY
read -rp "  AbuseIPDB API Key  (abuseipdb.com/account/api):   " ABUSE_KEY
read -rp "  Anthropic API Key  (console.anthropic.com):       " CLAUDE_KEY

python3 -c "
import json, sys
cfg = json.loads(open('$CONFIG_FILE').read())
if '$VT_KEY':    cfg['vt_api_key']    = '$VT_KEY'
if '$ABUSE_KEY': cfg['abuse_api_key'] = '$ABUSE_KEY'
if '$CLAUDE_KEY':cfg['claude_api_key']= '$CLAUDE_KEY'
open('$CONFIG_FILE','w').write(json.dumps(cfg, indent=2))
print('Keys saved.')
"
chmod 600 "$CONFIG_FILE"

# ── Restart service ───────────────────────────────────────────────────────────
log "Restarting KILLBOX service..."
systemctl restart killbox.service 2>/dev/null || warn "Restart manually: systemctl restart killbox"

IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "127.0.0.1")
echo ""
echo -e "${GREEN}${BOLD}Integration patch applied!${NC}"
echo ""
echo -e "  ${CYAN}Web UI:${NC}  http://${IP}:8080  (VT + AbuseIPDB + Heuristic tabs)"
echo ""
echo -e "  ${CYAN}CLI usage:${NC}"
echo -e "    kb-enrich vt hash  <sha256>"
echo -e "    kb-enrich vt url   <url>"
echo -e "    kb-enrich vt domain <domain>"
echo -e "    kb-enrich vt ip    <ip>"
echo -e "    kb-enrich abuse    <ip>"
echo -e "    kb-enrich abuse    ips.txt  --bulk"
echo -e "    kb-enrich heuristic <file>"
echo -e "    cat script.ps1 | kb-enrich heuristic -"
echo ""
echo -e "  ${CYAN}Configure keys later:${NC} kb-enrich --configure"
