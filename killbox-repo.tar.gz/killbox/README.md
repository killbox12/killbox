# KILLBOX — Threat Analysis Framework
### Malware & Email Analysis Engine v2.4.1

```
  ██╗  ██╗██╗██╗     ██╗     ██████╗  ██████╗ ██╗  ██╗
  ██║ ██╔╝██║██║     ██║     ██╔══██╗██╔═══██╗╚██╗██╔╝
  █████╔╝ ██║██║     ██║     ██████╔╝██║   ██║ ╚███╔╝
  ██╔═██╗ ██║██║     ██║     ██╔══██╗██║   ██║ ██╔██╗
  ██║  ██╗██║███████╗███████╗██████╔╝╚██████╔╝██╔╝ ██╗
  ╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝
```

> **For authorized security research only.** Deploy in isolated/air-gapped environments when analyzing live malware.

---

## Quick Start

### Option A — Bare Metal / VM (Debian 12)
```bash
# 1. Clone or download KILLBOX
git clone https://github.com/yourorg/killbox /tmp/killbox-src
cd /tmp/killbox-src

# 2. Copy your UI component
cp killbox.jsx app/src/App.jsx

# 3. Run installer
sudo bash install.sh

# 4. Open browser
http://<your-ip>:8080
```

### Option B — Docker (any platform)
```bash
cp killbox.jsx app/src/App.jsx
cd docker
docker compose up -d
# Open: http://localhost:8080
```

### Option C — Fedora / RHEL / Rocky Linux
```bash
sudo bash install-fedora.sh
```

---

## Prerequisites

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| RAM       | 2GB     | 8GB         |
| Disk      | 5GB     | 20GB        |
| CPU       | 2 cores | 4+ cores    |
| OS        | Debian 12, Ubuntu 22.04, Fedora 39, RHEL 9 | |
| Network   | For API calls + rule updates | Optional (air-gap mode) |

---

## What Gets Installed

### System Tools
```
yara 4.5.1          — malware pattern matching
radare2             — reverse engineering framework
binwalk             — firmware/binary extraction
foremost            — file carving
bulk-extractor      — artifact extraction
exiftool            — metadata analysis
strings/xxd/file    — binary analysis utils
strace/ltrace       — system call tracing
tshark/tcpdump      — packet capture & analysis
nmap                — network scanning
clamav              — antivirus scanning
p7zip / cabextract  — archive handling
```

### Python Tools (in /opt/killbox/venv)
```
pefile              — PE format parsing
yara-python         — YARA Python bindings
oletools            — Office/OLE malware analysis
python-magic        — file type detection
capstone            — multi-arch disassembly
scapy               — packet crafting/analysis
volatility3         — memory forensics
checkdmarc          — email auth validation
mailparser          — email parsing
msoffcrypto-tool    — Office crypto analysis
extract-msg         — Outlook MSG parsing
stix2               — threat intel standards
binwalk             — binary extraction
```

### Rule Sets & Intelligence
```
/opt/killbox/rules/signature-base/   — Florian Roth's YARA rules
/opt/killbox/rules/yara-rules/       — Community YARA rules
/opt/killbox/rules/rl-rules/         — ReversingLabs YARA rules
/opt/killbox/sigma/                  — Sigma detection rules (SigmaHQ)
/opt/killbox/mitre/enterprise-attack.json  — MITRE ATT&CK v14
```

---

## Web UI — Analysis Modules

| Module | Purpose |
|--------|---------|
| ⬡ Static Analysis | PE analysis, entropy, strings, obfuscation detection |
| ✉ Email Forensics | Headers, SPF/DKIM/DMARC, BEC, phishing, HTML smuggling |
| ◈ Behavioral Intel | Execution chains, persistence, evasion, C2 patterns |
| ⬢ Network IOCs | C2 beacons, DGA, DNS tunneling, Suricata rules |
| ◉ YARA Generator | Auto-generate multi-variant YARA rules from IOCs |
| ◎ Threat Hunt | APT attribution, Diamond Model, campaign analysis |

---

## CLI — kb-scan

```bash
# File analysis (hashes, entropy, strings, YARA)
kb-scan -f /samples/suspicious.exe

# Email forensics
kb-scan -e /samples/phishing.eml

# PCAP analysis
kb-scan -p /captures/traffic.pcap

# IP reputation
kb-scan -i 185.220.101.47

# Domain analysis
kb-scan -d evil-domain.com

# Office document (macros)
kb-scan -o /samples/invoice.docm

# YARA scan only
kb-scan -y /samples/malware.bin

# AV scan
kb-scan -av /samples/file.exe

# Update rules
kb-scan --update-rules
```

---

## Service Management

```bash
# Start / Stop / Restart
systemctl start killbox
systemctl stop killbox
systemctl restart killbox

# View logs
journalctl -u killbox -f

# Status
systemctl status killbox
```

---

## Docker Reference

```bash
# Build and run
docker compose up -d --build

# With API key in environment
ANTHROPIC_API_KEY=sk-ant-... docker compose up -d

# View logs
docker logs killbox -f

# Drop samples in
docker cp malware.exe killbox:/opt/killbox/samples/

# Run kb-scan in container
docker exec -it killbox kb-scan -f /opt/killbox/samples/malware.exe

# Stop
docker compose down
```

---

## API Key Configuration

KILLBOX uses the Anthropic Claude API for AI-powered analysis.

**Via Web UI:** Click `⬡ CONFIG` and paste your API key.

**Via Environment Variable:**
```bash
export ANTHROPIC_API_KEY=sk-ant-api03-...
```

**Via .env file (Docker):**
```bash
echo "ANTHROPIC_API_KEY=sk-ant-api03-..." > docker/.env
docker compose up -d
```

Get your API key at: https://console.anthropic.com

---

## Security Considerations

```
⚠ IMPORTANT — Read before deploying
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Always analyze malware in an ISOLATED VM or air-gapped network
• Never run live malware samples directly on host OS
• The web UI binds to 0.0.0.0:8080 — firewall appropriately
• Docker mode uses cap_add: NET_ADMIN and SYS_PTRACE — sandboxed
• API keys are stored in session memory only, never persisted
• ClamAV scans are informational — do not rely on AV alone
```

---

## Directory Structure

```
/opt/killbox/
├── app/                    Web UI (React/Vite)
│   ├── src/App.jsx         Main KILLBOX component
│   └── dist/               Built production files
├── venv/                   Python virtualenv
├── bin/
│   └── kb-scan             CLI analysis tool
├── rules/
│   ├── signature-base/     Florian Roth YARA rules
│   ├── yara-rules/         Community rules
│   └── rl-rules/           ReversingLabs rules
├── sigma/                  Sigma detection rules
├── mitre/
│   └── enterprise-attack.json
├── samples/                Drop samples here (Docker volume)
└── reports/                Saved analysis reports
```

---

## Updating

```bash
# Update YARA rules & ClamAV DB
kb-scan --update-rules

# Update KILLBOX
cd /tmp/killbox-src && git pull
sudo bash install.sh

# Update Docker image
docker compose pull && docker compose up -d --build
```

---

## License

For authorized security research and defensive purposes only.
KILLBOX © 2025 — MIT License
